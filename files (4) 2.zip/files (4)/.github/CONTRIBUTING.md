# Contributing to LSPD NextGen

Thank you for your interest in contributing to LSPD NextGen! This document provides guidelines for contributing to the project.

## Code of Conduct

- Be respectful and professional
- Focus on constructive feedback
- Help maintain a welcoming community
- Follow LSPDFR community standards

## How to Contribute

### Reporting Bugs
1. Check existing issues first
2. Use the bug report template
3. Provide detailed reproduction steps
4. Include system information and logs

### Suggesting Features
1. Use the feature request template
2. Describe the use case clearly
3. Consider implementation complexity
4. Think about LSPDFR integration

### Code Contributions
1. Fork the repository
2. Create a feature branch
3. Follow coding standards
4. Test thoroughly
5. Submit a pull request

## Development Setup

### Prerequisites
- Windows 10/11
- Visual Studio 2019+
- GTA V with RagePluginHook and LSPDFR
- .NET Framework 4.8

### Environment Setup
1. Clone your fork
2. Set GTA5Dir environment variable
3. Open LSPDNextGen.sln in Visual Studio
4. Build and test

## Coding Standards

### C# Guidelines
- Follow Microsoft C# conventions
- Use meaningful variable names
- Include XML documentation comments
- Handle exceptions appropriately
- Use async/await for I/O operations

### LSPDFR Specific
- Use Game.LogTrivial for logging
- Check LSPDFR state before operations
- Handle plugin lifecycle properly
- Respect LSPDFR API patterns

## Testing

### Before Submitting
- [ ] Code compiles without warnings
- [ ] Plugin loads in RagePluginHook
- [ ] Core functionality works
- [ ] No conflicts with LSPDFR
- [ ] Performance is acceptable

### Test Cases
1. Fresh installation
2. Upgrade from previous version
3. Multiple officer scenarios
4. Large dataset handling
5. Error conditions

## Pull Request Process

### Checklist
- [ ] Branch is up to date with main
- [ ] All tests pass
- [ ] Code follows style guidelines
- [ ] Documentation is updated
- [ ] Breaking changes are documented

### Review Process
1. Automated checks must pass
2. Code review by maintainer
3. Testing by community (if needed)
4. Merge when approved

## Documentation

### Required Updates
- Update README.md if needed
- Add/update API documentation
- Include CHANGELOG.md entry
- Update BUILD.md if process changes

### Documentation Standards
- Clear, concise language
- Step-by-step instructions
- Code examples where helpful
- Keep up to date with changes

## Community

### Communication
- GitHub Issues for bugs/features
- Discussions for questions
- LSPDFR forums for community
- Respectful communication always

### Support
- Help others in issues
- Share knowledge and experience
- Test pre-release versions
- Provide feedback on changes

## Recognition

Contributors will be:
- Listed in CONTRIBUTORS.md
- Credited in release notes
- Recognized in documentation
- Appreciated by the community!

## Getting Help

### Resources
- Project documentation
- LSPDFR API documentation
- C# and .NET resources
- Visual Studio documentation

### Contact
- Open an issue for questions
- Use discussions for general help
- Check existing documentation first
- Be patient and respectful

Thank you for contributing to LSPD NextGen! 🚔
