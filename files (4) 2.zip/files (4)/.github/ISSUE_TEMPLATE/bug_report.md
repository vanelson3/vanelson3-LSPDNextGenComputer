---
name: Bug Report
about: Create a report to help us improve LSPD NextGen
title: '[BUG] '
labels: bug
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**Expected behavior**
A clear and concise description of what you expected to happen.

**Screenshots**
If applicable, add screenshots to help explain your problem.

**Environment (please complete the following information):**
 - OS: [e.g. Windows 10, Windows 11]
 - GTA V Version: [e.g. Steam, Epic, Rockstar]
 - RagePluginHook Version: [e.g. 1.108]
 - LSPDFR Version: [e.g. 0.4.9]
 - LSPD NextGen Version: [e.g. 1.0.0]

**RagePluginHook Console Log**
If available, paste the relevant RagePluginHook console output here:
```
[Paste console output here]
```

**Additional context**
Add any other context about the problem here.

**Checklist**
- [ ] I have searched for existing issues
- [ ] I have verified LSPDFR is working properly
- [ ] I have tried with only LSPD NextGen loaded
- [ ] I have included the RagePluginHook console log
