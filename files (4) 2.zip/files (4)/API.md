# LSPD NextGen API Documentation

## Overview

LSPD NextGen provides a comprehensive API for other plugin developers to integrate with the officer management, callout system, report generation, and suspect database functionality.

## Getting Started

To use the LSPD NextGen API in your plugin, add a reference to the LSPD NextGen assembly and check if it's loaded:

```csharp
using LSPDNextGen;

// Check if LSPD NextGen is available
if (LSPDNextGen.IsInitialized)
{
    // Safe to use API methods
    var officerManager = LSPDNextGen.GetOfficerManager();
}
```

## API Classes

### LSPDNextGen (Main Class)

The main entry point for accessing all API functionality.

#### Static Properties
- `bool IsInitialized` - Returns true if LSPD NextGen is loaded and initialized

#### Static Methods
- `OfficerManager GetOfficerManager()` - Gets the officer management system
- `CalloutManager GetCalloutManager()` - Gets the callout management system  
- `ReportManager GetReportManager()` - Gets the report generation system
- `SuspectDatabase GetSuspectDatabase()` - Gets the suspect database system

### OfficerManager

Manages officer information, status, and assignments.

#### Key Methods

```csharp
// Get current officer on duty
Officer GetCurrentOfficer()

// Find officer by badge number
Officer FindOfficerByBadge(string badgeNumber)

// Search officers by name
List<Officer> FindOfficersByName(string name)

// Add new officer
bool AddOfficer(Officer officer)

// Update officer information
bool UpdateOfficer(Officer updatedOfficer)

// Update officer status
bool UpdateOfficerStatus(string badgeNumber, string status, string location = "")

// Get officers by status
List<Officer> GetOfficersByStatus(string status)

// Assign vehicle to officer
bool AssignVehicle(string badgeNumber, string vehicleInfo)

// Set officer partnership
bool SetPartner(string officerBadge, string partnerBadge)
```

#### Officer Class

```csharp
public class Officer
{
    public string Name { get; set; }
    public string BadgeNumber { get; set; }
    public string Rank { get; set; }
    public string Department { get; set; }
    public string Division { get; set; }
    public string Shift { get; set; }
    public int Experience { get; set; }
    public List<string> Certifications { get; set; }
    public ContactInfo ContactInfo { get; set; }
    public string Status { get; set; }
    public string Location { get; set; }
    public string Vehicle { get; set; }
    public string Partner { get; set; }
    public string Created { get; set; }
    public string LastActive { get; set; }
}
```

### CalloutManager

Manages callout creation, assignment, and tracking.

#### Key Methods

```csharp
// Get all active callouts
List<CalloutRecord> GetActiveCallouts()

// Get callout history
List<CalloutRecord> GetCalloutHistory(int maxRecords = 50)

// Find specific callout
CalloutRecord FindCallout(string calloutId)

// Create new callout
string CreateCallout(string type, string description, Vector3 location, 
                    string address = "", CalloutPriority priority = CalloutPriority.Medium)

// Assign officer to callout
bool AssignOfficer(string calloutId, string officerBadge)

// Update callout status
bool UpdateCalloutStatus(string calloutId, string status, string notes = "")

// Add evidence to callout
bool AddEvidence(string calloutId, string evidence)

// Add suspect to callout
bool AddSuspect(string calloutId, string suspectInfo)

// Add witness to callout
bool AddWitness(string calloutId, string witnessInfo)

// Get callouts by priority
List<CalloutRecord> GetCalloutsByPriority(CalloutPriority priority)
```

#### CalloutRecord Class

```csharp
public class CalloutRecord
{
    public string CalloutId { get; set; }
    public string Type { get; set; }
    public string Priority { get; set; }
    public string Status { get; set; }
    public LocationInfo Location { get; set; }
    public string Description { get; set; }
    public List<string> AssignedOfficers { get; set; }
    public string ResponseTime { get; set; }
    public string CompletionTime { get; set; }
    public List<string> Evidence { get; set; }
    public List<string> Suspects { get; set; }
    public List<string> Witnesses { get; set; }
    public string Notes { get; set; }
    public string Created { get; set; }
    public string LastUpdated { get; set; }
}
```

### ReportManager

Handles police report creation, management, and approval.

#### Key Methods

```csharp
// Create new report from template
string CreateReport(string templateName, string title, string officerBadge)

// Get report by ID
PoliceReport GetReport(string reportId)

// Update existing report
bool UpdateReport(PoliceReport updatedReport)

// Finalize draft report
bool FinalizeReport(string reportId)

// Approve report (supervisor function)
bool ApproveReport(string reportId, string approvingOfficer)

// Add involved person to report
bool AddInvolvedPerson(string reportId, InvolvedPerson person)

// Add evidence to report
bool AddEvidence(string reportId, EvidenceItem evidence)

// Add witness to report
bool AddWitness(string reportId, Witness witness)

// Add charges to report
bool AddCharge(string reportId, Charge charge)

// Get reports by officer
List<PoliceReport> GetReportsByOfficer(string officerBadge)

// Get pending reports
List<PoliceReport> GetPendingReports()

// Get draft reports
List<PoliceReport> GetDraftReports()
```

#### PoliceReport Class

```csharp
public class PoliceReport
{
    public string ReportId { get; set; }
    public string Type { get; set; }
    public string Title { get; set; }
    public string OfficerInCharge { get; set; }
    public List<string> AssistingOfficers { get; set; }
    public string DateTime { get; set; }
    public LocationInfo Location { get; set; }
    public string Summary { get; set; }
    public string Details { get; set; }
    public List<InvolvedPerson> InvolvedPersons { get; set; }
    public List<EvidenceItem> Evidence { get; set; }
    public List<Witness> Witnesses { get; set; }
    public List<Charge> Charges { get; set; }
    public string Disposition { get; set; }
    public bool FollowUpRequired { get; set; }
    public bool Approved { get; set; }
    public string ApprovedBy { get; set; }
    public string Status { get; set; }
    public string Created { get; set; }
    public string LastModified { get; set; }
}
```

### SuspectDatabase

Manages suspect information, warrants, and criminal history.

#### Key Methods

```csharp
// Search suspects by name
List<Suspect> SearchByName(string firstName, string lastName = "")

// Find suspect by ID
Suspect FindById(string suspectId)

// Search by physical description
List<Suspect> SearchByDescription(string race = "", string gender = "", 
                                 string hairColor = "", string eyeColor = "")

// Check active warrants
List<Warrant> CheckWarrants(string suspectId)

// Get criminal history
List<ArrestRecord> GetCriminalHistory(string suspectId)

// Add new suspect
bool AddSuspect(Suspect suspect)

// Update suspect information
bool UpdateSuspect(Suspect updatedSuspect)

// Add warrant
bool AddWarrant(Warrant warrant)

// Serve warrant
bool ServeWarrant(string warrantId, string servingOfficer)

// Add arrest record
bool AddArrestRecord(ArrestRecord arrest)

// Get suspects by gang
List<Suspect> GetSuspectsByGang(string gang)

// Get suspects by danger level
List<Suspect> GetSuspectsByDangerLevel(string dangerLevel)
```

#### Suspect Class

```csharp
public class Suspect
{
    public string Id { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string DateOfBirth { get; set; }
    public string Gender { get; set; }
    public string Race { get; set; }
    public string Height { get; set; }
    public string Weight { get; set; }
    public string EyeColor { get; set; }
    public string HairColor { get; set; }
    public string Address { get; set; }
    public string Phone { get; set; }
    public List<string> Warrants { get; set; }
    public List<string> PriorArrests { get; set; }
    public List<string> KnownAssociates { get; set; }
    public string Gang { get; set; }
    public string Notes { get; set; }
    public string DangerLevel { get; set; }
    public string LastSeen { get; set; }
    public string Created { get; set; }
    public string LastUpdated { get; set; }
}
```

## Usage Examples

### Example 1: Creating a Traffic Stop Report

```csharp
public void CreateTrafficStopReport(string officerBadge, string violatorName, string location)
{
    if (!LSPDNextGen.IsInitialized) return;
    
    var reportManager = LSPDNextGen.GetReportManager();
    var reportId = reportManager.CreateReport("Traffic Stop", 
                                            $"Traffic Stop - {violatorName}", 
                                            officerBadge);
    
    if (!string.IsNullOrEmpty(reportId))
    {
        var report = reportManager.GetReport(reportId);
        report.Location.Address = location;
        report.Summary = $"Traffic stop conducted on {violatorName} for moving violation.";
        
        // Add involved person
        var violator = new InvolvedPerson
        {
            Name = violatorName,
            Role = "Violator",
            Description = "Driver of vehicle"
        };
        reportManager.AddInvolvedPerson(reportId, violator);
        
        // Update and finalize
        reportManager.UpdateReport(report);
        reportManager.FinalizeReport(reportId);
    }
}
```

### Example 2: Creating and Managing a Callout

```csharp
public void CreateEmergencyCallout(Vector3 location, string description)
{
    if (!LSPDNextGen.IsInitialized) return;
    
    var calloutManager = LSPDNextGen.GetCalloutManager();
    var officerManager = LSPDNextGen.GetOfficerManager();
    
    // Create high priority callout
    var calloutId = calloutManager.CreateCallout("Emergency Response", 
                                               description, 
                                               location, 
                                               "Downtown Los Santos", 
                                               CalloutPriority.Emergency);
    
    if (!string.IsNullOrEmpty(calloutId))
    {
        // Assign current officer
        var currentOfficer = officerManager.GetCurrentOfficer();
        if (currentOfficer != null)
        {
            calloutManager.AssignOfficer(calloutId, currentOfficer.BadgeNumber);
            calloutManager.UpdateCalloutStatus(calloutId, "En Route", "Officer responding");
        }
    }
}
```

### Example 3: Searching for Suspects

```csharp
public void PerformSuspectSearch(string firstName, string lastName)
{
    if (!LSPDNextGen.IsInitialized) return;
    
    var suspectDB = LSPDNextGen.GetSuspectDatabase();
    
    // Search by name
    var suspects = suspectDB.SearchByName(firstName, lastName);
    
    foreach (var suspect in suspects)
    {
        // Check for active warrants
        var warrants = suspectDB.CheckWarrants(suspect.Id);
        if (warrants.Count > 0)
        {
            Game.DisplayNotification($"~r~WARRANT ALERT~w~\n{suspect.FirstName} {suspect.LastName}\n{warrants.Count} active warrant(s)");
        }
        
        // Get criminal history
        var arrests = suspectDB.GetCriminalHistory(suspect.Id);
        Game.LogTrivial($"Suspect {suspect.Id} has {arrests.Count} prior arrests");
    }
}
```

### Example 4: Integration with Other Plugins

```csharp
// In your plugin's Initialize method
public override void Initialize()
{
    // Wait for LSPD NextGen to initialize
    GameFiber.StartNew(() =>
    {
        while (!LSPDNextGen.IsInitialized)
        {
            GameFiber.Sleep(1000);
        }
        
        // Now safe to use LSPD NextGen API
        RegisterLSPDNextGenIntegration();
    });
}

private void RegisterLSPDNextGenIntegration()
{
    var officerManager = LSPDNextGen.GetOfficerManager();
    var currentOfficer = officerManager.GetCurrentOfficer();
    
    if (currentOfficer != null)
    {
        Game.LogTrivial($"Integrated with LSPD NextGen - Officer: {currentOfficer.Name}");
        
        // Your integration logic here
        SetupOfficerStatusUpdates();
        RegisterCalloutHandlers();
    }
}
```

## Best Practices

### Error Handling

Always check if LSPD NextGen is initialized before using the API:

```csharp
if (!LSPDNextGen.IsInitialized)
{
    Game.LogTrivial("LSPD NextGen not available");
    return;
}
```

### Performance Considerations

- Cache frequently accessed data instead of repeated API calls
- Use background GameFibers for data-intensive operations
- Limit the frequency of status updates to avoid performance impact

### Data Validation

Validate data before passing to API methods:

```csharp
public bool SafeAddSuspect(Suspect suspect)
{
    if (string.IsNullOrEmpty(suspect.FirstName) || string.IsNullOrEmpty(suspect.LastName))
    {
        Game.LogTrivial("Suspect name is required");
        return false;
    }
    
    return LSPDNextGen.GetSuspectDatabase().AddSuspect(suspect);
}
```

## Events and Callbacks

Currently, LSPD NextGen does not expose events directly. Future versions may include:

- Officer status change events
- Callout creation/completion events  
- Report submission events
- Warrant activation events

## Version Compatibility

This API documentation is for LSPD NextGen v1.0.0. Future versions will maintain backward compatibility where possible, but breaking changes will be clearly documented in the changelog.

## Support

For API support and questions:
- GitHub Issues: Technical problems and feature requests
- Documentation: Complete API reference and examples
- Community Forum: Integration discussions and examples

## Future API Enhancements

Planned for future releases:
- Event system for real-time notifications
- Advanced search and filtering methods
- Bulk operations for large datasets
- Custom data field support
- Web API for external integrations
