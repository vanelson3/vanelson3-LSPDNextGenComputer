# Build Environment Setup for LSPDFR Plugin

## The Issue
The build is failing because the project references RagePluginHook and LSPDFR DLLs that need to be found during compilation.

## Quick Fix Options

### Option 1: Set Environment Variable (Recommended)
```cmd
# Windows Command Prompt
set GTA5Dir=C:\Program Files (x86)\Steam\steamapps\common\Grand Theft Auto V

# Windows PowerShell  
$env:GTA5Dir = "C:\Program Files (x86)\Steam\steamapps\common\Grand Theft Auto V"

# Then run build
build.bat
```

### Option 2: Copy Required DLLs to Project
Create a `libs` folder and copy these files:
- `RagePluginHook.exe` (from your GTA V folder)
- `LSPD First Response.dll` (from your GTA V/plugins/ folder)

### Option 3: Build in Visual Studio
1. Open `LSPDNextGen.sln` in Visual Studio
2. Right-click the project → Properties
3. Go to Reference Paths
4. Add your GTA V installation folder
5. Build with Ctrl+Shift+B

## Environment Variable Setup by GTA V Version

### Steam Version
```
C:\Program Files (x86)\Steam\steamapps\common\Grand Theft Auto V
```

### Epic Games Version  
```
C:\Program Files\Epic Games\GTAV
```

### Rockstar Games Launcher
```
C:\Program Files\Rockstar Games\Grand Theft Auto V
```

### Social Club Version
```
C:\Program Files (x86)\Rockstar Games\Grand Theft Auto V
```

## Verification
After setting GTA5Dir, verify it works:
```cmd
echo %GTA5Dir%
dir "%GTA5Dir%\RagePluginHook.exe"
dir "%GTA5Dir%\plugins\LSPD First Response.dll"
```

All three commands should succeed for the build to work.
