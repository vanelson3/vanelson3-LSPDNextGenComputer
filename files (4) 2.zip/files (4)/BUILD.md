# Build Instructions for LSPDNextGen

## Prerequisites
- Visual Studio 2019 or later
- .NET Framework 4.8 SDK
- GTA V with RagePluginHook and LSPDFR installed

## Setting Up the Development Environment

### 1. Clone the Repository
```bash
git clone https://github.com/yourusername/LSPDNextGen.git
cd LSPDNextGen
```

### 2. Set Up References
Before building, you need to update the reference paths in the project file to match your GTA V installation:

1. Open `LSPDNextGen.csproj` in a text editor
2. Update these reference paths to point to your GTA V directory:
   ```xml
   <Reference Include="RagePluginHook">
     <HintPath>C:\Program Files (x86)\Steam\steamapps\common\Grand Theft Auto V\RagePluginHook.exe</HintPath>
   </Reference>
   <Reference Include="LSPD First Response">
     <HintPath>C:\Program Files (x86)\Steam\steamapps\common\Grand Theft Auto V\plugins\LSPD First Response.dll</HintPath>
   </Reference>
   ```

### 3. Restore NuGet Packages
```bash
nuget restore
```
Or use Visual Studio's Package Manager to restore packages.

### 4. Build the Project
Open the solution in Visual Studio and build in Release mode, or use command line:
```bash
msbuild LSPDNextGen.sln /p:Configuration=Release
```

### 5. Copy Output
After building, copy `bin/Release/LSPDNextGen.dll` to your GTA V `plugins/LSPD First Response/` folder.

## Debugging

### 1. Set Up Debug Environment
1. In Visual Studio, go to Project Properties > Debug
2. Set "Start external program" to your `RagePluginHook.exe` path
3. Set "Working directory" to your GTA V directory

### 2. Attach to Process
Alternatively, you can start GTA V and LSPDFR normally, then attach the Visual Studio debugger to the `GTA5.exe` process.

## Testing

### 1. Basic Functionality Test
1. Start GTA V with LSPDFR
2. Go on duty
3. Press F7 to open the computer system
4. Test each module (Officer Management, Callouts, Reports, Suspects)

### 2. Integration Testing
Test with popular LSPDFR plugins:
- Grammar Police
- Stop The Ped
- ALPR
- Computer+

## Distribution

### Creating a Release Package
1. Build the project in Release mode
2. Create the following folder structure:
   ```
   LSPDNextGen-v1.0.0/
   ├── plugins/
   │   └── LSPD First Response/
   │       ├── LSPDNextGen.dll
   │       └── LSPDNextGen.ini
   ├── lspdfr/
   │   └── Data/
   │       └── .keep
   ├── README.txt
   └── LICENSE
   ```
3. Zip the folder for distribution

### File Checksums
Consider providing checksums for security:
```bash
certutil -hashfile LSPDNextGen.dll SHA256
```

## Common Build Issues

### Missing References
If you get reference errors:
1. Verify GTA V, RagePluginHook, and LSPDFR are properly installed
2. Update reference paths in the project file
3. Ensure you're using the correct .NET Framework version (4.8)

### Runtime Errors
If the plugin fails to load:
1. Check the RagePluginHook console for error messages
2. Verify all dependencies are present
3. Ensure the plugin is in the correct folder
4. Check file permissions

### JSON Serialization Issues
If you encounter JSON-related errors:
1. Verify Newtonsoft.Json.dll is present
2. Check for version conflicts with other plugins
3. Ensure JSON files are not corrupted

## Contributing

### Code Style
- Use C# naming conventions
- Add XML documentation comments for public methods
- Include error handling with appropriate logging
- Follow the existing code structure and patterns

### Pull Requests
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request with a clear description

### Bug Reports
When reporting bugs, include:
- Game version
- RagePluginHook version
- LSPDFR version
- Plugin version
- Steps to reproduce
- Error logs

## Version Management

### Updating Assembly Version
Update version numbers in:
1. `Properties/AssemblyInfo.cs`
2. `LSPDNextGen.ini` (if applicable)
3. README.md
4. Release notes

### Changelog
Maintain a changelog documenting:
- New features
- Bug fixes
- Breaking changes
- Known issues
