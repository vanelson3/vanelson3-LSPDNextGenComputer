# LSPD NextGen - Installation Guide

## 📦 Easy Drag & Drop Installation

### Prerequisites
- **GTA V** (Steam, Epic, or Rockstar version)
- **RagePluginHook** (Latest version)
- **LSPD First Response** (0.4.9 or newer)
- **.NET Framework 4.8** (Usually pre-installed on Windows 10/11)

### 🎯 Quick Installation (Drag & Drop)

1. **Download** the latest release from the releases page
2. **Extract** the ZIP file to a temporary location
3. **Copy** the contents of the `Release` folder to your **GTA V directory**

The file structure should look like this in your GTA V folder:
```
GTA V/
├── plugins/
│   ├── LSPDNextGen.dll          ← Plugin file
│   └── LSPDNextGen.ini          ← Configuration file
└── lspdfr/
    └── data/
        └── LSPDNextGen/
            ├── settings.json     ← Main settings
            ├── officers.json     ← Officer data
            ├── callouts.json     ← Callout history
            ├── reports.json      ← Report database
            ├── suspects.json     ← Suspect database
            └── vehicles.json     ← Vehicle database
```

### 🚀 Launch Instructions

1. **Start GTA V** with RagePluginHook
2. **Load LSPDFR** (go on duty)
3. **Press F7** to open the LSPD NextGen Computer
4. **Enjoy** the enhanced police computer system!

### ⚙️ Configuration

The plugin will automatically create default configuration files on first run. You can customize:

- **Keybindings** in `plugins/LSPDNextGen.ini`
- **Advanced settings** in `lspdfr/data/LSPDNextGen/settings.json`
- **UI preferences** through the in-game interface

### 🔧 Manual Installation (Advanced Users)

If you prefer manual installation:

1. Place `LSPDNextGen.dll` in `GTA V/plugins/`
2. Place `LSPDNextGen.ini` in `GTA V/plugins/`
3. Create folder `GTA V/lspdfr/data/LSPDNextGen/`
4. Copy all JSON files to the LSPDNextGen folder
5. Restart GTA V and RagePluginHook

### 📁 File Locations

| File Type | Location | Purpose |
|-----------|----------|---------|
| Plugin DLL | `plugins/LSPDNextGen.dll` | Main plugin executable |
| Configuration | `plugins/LSPDNextGen.ini` | Basic settings and keybinds |
| Data Files | `lspdfr/data/LSPDNextGen/*.json` | Database and user data |
| Logs | `lspdfr/logs/LSPDNextGen.log` | Debug and error logs |

### ⚠️ Troubleshooting

**Plugin doesn't load:**
- Ensure RagePluginHook and LSPDFR are up to date
- Check the RagePluginHook console for error messages
- Verify .NET Framework 4.8 is installed

**F7 key doesn't work:**
- Check `plugins/LSPDNextGen.ini` for correct keybind
- Ensure you're on duty in LSPDFR
- Try a different key combination if F7 conflicts

**Data not saving:**
- Verify the `lspdfr/data/LSPDNextGen/` folder exists
- Check file permissions (run GTA V as administrator if needed)
- Review logs in `lspdfr/logs/LSPDNextGen.log`

### 🔄 Updating

To update the plugin:
1. **Backup** your `lspdfr/data/LSPDNextGen/` folder
2. **Replace** the DLL and INI files with new versions
3. **Merge** any new configuration options
4. **Restore** your backed-up data files

### 💡 Tips

- The plugin automatically creates backup files
- All data is stored in JSON format for easy editing
- Press F7 while in a police vehicle for best experience
- Customize the interface through the settings menu

**Enjoy your enhanced LSPDFR experience with LSPD NextGen!**
