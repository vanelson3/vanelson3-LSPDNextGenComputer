# LSPD NextGen Computer 🚔

**A comprehensive, modern police computer system for LSPDFR**

LSPD NextGen Computer is a professional-grade police computer system mod for LSPDFR (Los Santos Police Department First Response) in Grand Theft Auto V. Designed with real police workflow in mind, this plugin provides an immersive, streamlined, and highly functional interface for officers in the field.

---

## 🎯 Key Features

- **🎮 Easy Installation:** Simple drag-and-drop installation - just extract to your GTA V directory
- **💻 Modern Police Computer:** Access via F7 key with responsive, user-friendly interface
- **👮 Officer Management:** Complete officer tracking, shifts, partnerships, and status updates
- **🔍 Suspect Database:** Comprehensive criminal records, warrants, and investigation tools
- **📻 Callout System:** Dynamic dispatch, assignment, and real-time callout management
- **📋 Report Generator:** Professional police reports with templates and approval workflow
- **🚗 Vehicle Database:** Vehicle information, registrations, and alert system
- **⚙️ Fully Configurable:** Customizable keybinds, themes, and feature toggles
- **💾 Smart Data System:** Automatic backups and JSON-based persistence
- **🔌 LSPDFR Integration:** Native integration with LSPDFR APIs and community plugins

---

## 🗂️ File and Folder Structure

```
LSPDNextGenComputer/
├─ plugins/
│   └─ LSPD NextGen/
│       ├─ LSPDNextGen.dll           # Main plugin DLL (compiled)
│       ├─ LSPDNextGen.ini           # User configuration file
│       ├─ Newtonsoft.Json.dll       # Dependency (if used)
│       ├─ LICENSE                   # License file
│       ├─ README.txt                # User instructions
│       └─ [Assets, Icons, etc.]
├─ lspdfr/
│   └─ Data/
│       └─ .keep                     # Ensures Data folder is present
├─ .github/
│   └─ workflows/
│       └─ build.yml                 # GitHub Actions build workflow
├─ .gitignore
└─ README.md
```

---

## ⚙️ Configuration Example (`LSPDNextGen.ini`)

```ini
[General]
OpenComputerKey=F7
ShowNotifications=true
Theme=Dark

[Integrations]
EnableGrammarPolice=true
EnableStopThePed=true
```

---

## 🛠️ Installation

1. **Download** the latest release ZIP from GitHub.
2. **Extract** the ZIP.
3. **Drag and drop** the `plugins` and `lspdfr` folders into your Grand Theft Auto V game directory.
4. **Launch LSPDFR** and press **F7** in-game to access the computer.

---

## 🔒 License

MIT License — see LICENSE file for full terms.

---

## 👨‍💻 Developer Notes

- Project is written in C# targeting .NET Framework 4.8.
- Utilizes RagePluginHook and LSPDFR SDK.
- Data files (officers, suspects, callouts, reports) are stored as JSON in `lspdfr/Data/`.
- GitHub Actions workflow included for automated builds and packaging.
- Easily extensible for new features, integrations, or UI improvements.

---

## 💬 Support & Feedback

For bug reports, suggestions, or contributions, please open an issue or pull request on the GitHub repository.

---

## 🚓 Credits

- **Author:** vanelson3
- **Inspiration:** Compulite, other leading LSPDFR plugins
- **Contributors:** [Your name here!]

---