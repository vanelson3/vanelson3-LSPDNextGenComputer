LSPD NextGen Computer - LSPDFR Plugin

INSTALLATION:
1. Extract this ZIP.
2. Drag and drop the 'plugins' and 'lspdfr' folders into your Grand Theft Auto V game directory.
3. Launch LSPDFR. Press F7 in-game to open the Police Computer.

NOTES:
- All data files are auto-created in lspdfr/Data/ on first run.
- Demo officers, suspects, callouts, and reports are included automatically.
- Configure hotkeys and integrations in LSPDNextGen.ini if desired.