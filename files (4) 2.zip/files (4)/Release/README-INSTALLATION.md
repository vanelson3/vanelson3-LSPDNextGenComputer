# LSPD NextGen Computer - LSPDFR Installation

## 🚔 For LSPDFR Users

**Welcome to LSPD NextGen Computer!** This is a professional police computer system designed specifically for LSPDFR (Los Santos Police Department First Response).

### 📦 Installation Instructions

1. **Extract** this ZIP file to a temporary location
2. **Navigate** to your GTA V installation folder
3. **Drag and drop** the contents of this folder into your GTA V directory
4. **Launch** GTA V with RagePluginHook
5. **Go on duty** in LSPDFR
6. **Press F7** to open the computer system

### 📁 What Gets Installed

```
Your GTA V Folder/
├── plugins/
│   ├── LSPDNextGen.dll      ← Main plugin
│   └── LSPDNextGen.ini      ← Configuration
└── lspdfr/
    └── data/
        └── LSPDNextGen/     ← Your data files
            ├── settings.json
            ├── officers.json
            ├── callouts.json
            ├── reports.json
            ├── suspects.json
            └── vehicles.json
```

### 🎮 How to Use

- **Press F7** (configurable) to open the computer
- **Officer Management** - Track your fellow officers
- **Suspect Database** - Search criminal records and warrants
- **Callout System** - Manage dispatch and assignments
- **Report Generator** - Create professional police reports
- **Vehicle Database** - Check registrations and alerts

### ⚙️ Configuration

- **Basic settings**: Edit `plugins/LSPDNextGen.ini`
- **Advanced settings**: Modify `lspdfr/data/LSPDNextGen/settings.json`
- **In-game settings**: Use the computer interface

### 🔧 Requirements

- **GTA V** (any version)
- **RagePluginHook** (latest version)
- **LSPD First Response** (0.4.9 or newer)
- **.NET Framework 4.8** (usually pre-installed)

### 🎯 Features

- ✅ **Modern Interface** - Clean, responsive design
- ✅ **Real Police Workflow** - Based on real procedures
- ✅ **Data Persistence** - All your data is saved automatically
- ✅ **Customizable** - Adjust settings to your preference
- ✅ **LSPDFR Integration** - Works seamlessly with other plugins
- ✅ **Professional Reports** - Generate official-looking documents

### 🚨 Troubleshooting

**Plugin doesn't appear:**
- Check RagePluginHook console for errors
- Ensure LSPDFR is loaded and you're on duty
- Verify all files copied to correct locations

**F7 key doesn't work:**
- Check if another plugin uses F7
- Change the key in `plugins/LSPDNextGen.ini`
- Make sure you're in a police vehicle or on foot while on duty

**Data not saving:**
- Run GTA V as Administrator
- Check folder permissions
- Verify the `lspdfr/data/LSPDNextGen/` folder exists

### 💡 Tips for Best Experience

- Use while in a police vehicle for full immersion
- Customize the interface theme in settings
- Set up officer profiles for your department
- Use the backup system to save important data

### 🔄 Updates

To update the plugin:
1. Backup your `lspdfr/data/LSPDNextGen/` folder
2. Replace the DLL and INI files with new versions
3. Restore your backed-up data

---

**Enjoy your enhanced LSPDFR experience with LSPD NextGen Computer!**

*For support, documentation, and updates, visit the project repository.*
