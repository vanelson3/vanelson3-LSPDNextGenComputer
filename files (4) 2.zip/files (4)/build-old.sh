#!/bin/bash

echo
echo "=========================    echo "🚔 LSPDFR Installation Instructions:"   echo "🚔 LSPDFR Installation Instructions:"================"
echo "  LSPD NextGen - LSPDFR Plugin Builder"
echo "=========================================="
echo
echo "Preparing LSPDFR-compatible build..."
echo

# Check for required dependencies
echo "Checking LSPDFR compatibility..."
if [ ! -f "src/LSPDNextGen.cs" ]; then
    echo "❌ Error: Main plugin file not found!"
    echo "Make sure you're running this from the project root."
    exit 1
fi

# Clean previous builds
echo "Cleaning previous builds..."
if [ -f "Release/plugins/LSPDNextGen.dll" ]; then
    rm "Release/plugins/LSPDNextGen.dll"
fi
if [ -f "Release/plugins/LSPDNextGen.pdb" ]; then
    rm "Release/plugins/LSPDNextGen.pdb"
fi
if [ -f "Release/plugins/LSPDNextGen.ini" ]; then
    rm "Release/plugins/LSPDNextGen.ini"
fi

# Ensure LSPDFR folder structure exists
echo "Creating LSPDFR folder structure..."
mkdir -p "Release/plugins"
mkdir -p "Release/lspdfr/data/LSPDNextGen"

# Build the project
echo "Building Release configuration for LSPDFR..."
dotnet build LSPDNextGen.sln -c Release --verbosity minimal

# Check if build was successful
if [ -f "Release/plugins/LSPDNextGen.dll" ]; then
    echo
    echo "✅ LSPDFR Plugin Build Successful!"
    echo
    echo "📦 LSPDFR Installation Package Ready:"
    echo "   ├── plugins/LSPDNextGen.dll      (Main plugin)"
    echo "   ├── plugins/LSPDNextGen.ini      (Configuration)"
    echo "   └── lspdfr/data/LSPDNextGen/     (Data files)"
    echo
    echo "� LSPDFR Installation Instructions:"
    echo "   1. Navigate to your GTA V installation folder"
    echo "   2. Drag and drop the contents of 'Release' folder"
    echo "   3. Launch GTA V with RagePluginHook"
    echo "   4. Go on duty in LSPDFR"
    echo "   5. Press F7 to open LSPD NextGen Computer"
    echo
    echo "📋 LSPDFR Requirements Met:"
    echo "   ✅ RagePluginHook compatible"
    echo "   ✅ LSPDFR API integration"
    echo "   ✅ Standard folder structure"
    echo "   ✅ Auto data initialization"
    echo
    echo "🎯 Ready for LSPDFR community distribution!"
    echo
else
    echo
    echo "❌ LSPDFR Plugin Build Failed!"
    echo
    echo "🔍 Troubleshooting:"
    echo "   - Check if .NET SDK is installed"
    echo "   - Verify .NET Framework 4.8 is available"
    echo "   - Ensure GTA5Dir environment variable is set"
    echo "   - Check the build output above for specific errors"
    echo
    echo "📖 For help, see BUILD.md in the project folder"
    echo
fi
