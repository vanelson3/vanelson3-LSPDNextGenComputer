#!/bin/bash

echo
echo "📦 Creating LSPDFR Plugin Distribution Package..."
echo

# Get version from project
VERSION="v1.0.0"
PACKAGE_NAME="LSPDNextGen-${VERSION}"

# Create distribution folder
rm -rf "dist"
mkdir -p "dist"

# Copy all necessary files
echo "📁 Copying project files..."
rsync -av --exclude='.git' \
          --exclude='.DS_Store' \
          --exclude='dist' \
          --exclude='*.log' \
          --exclude='bin' \
          --exclude='obj' \
          . "dist/${PACKAGE_NAME}/"

# Create the ZIP package
cd dist || exit 1
echo "🗜️  Creating ZIP package..."
zip -r "${PACKAGE_NAME}.zip" "${PACKAGE_NAME}/" -q

echo
echo "✅ Distribution package created successfully!"
echo
echo "📦 Package: dist/${PACKAGE_NAME}.zip"
echo "📁 Size: $(du -h "${PACKAGE_NAME}.zip" | cut -f1)"
echo
echo "🚀 Ready for distribution to Windows LSPDFR users!"
echo
echo "📋 Package Contents:"
echo "   • Complete C# source code"
echo "   • Visual Studio project files"
echo "   • Build scripts for Windows"
echo "   • LSPDFR-ready folder structure"
echo "   • Comprehensive documentation"
echo "   • Installation guides"
echo
echo "💡 Users will:"
echo "   1. Download and extract this ZIP"
echo "   2. Run build.bat on Windows"
echo "   3. Install to their GTA V directory"
echo

# Show final package info
ls -la "${PACKAGE_NAME}.zip"
echo
echo "🎯 Your LSPDFR plugin is ready for the community!"
