# LSPDFR Reference Libraries

This folder is for local LSPDFR reference files when the GTA5Dir environment variable is not set.

## Required Files (copy from your GTA V installation):

1. **RagePluginHook.exe**
   - Source: `{GTA V Root}/RagePluginHook.exe`
   - Copy to: `libs/RagePluginHook.exe`

2. **LSPD First Response.dll**
   - Source: `{GTA V Root}/plugins/LSPD First Response.dll`
   - Copy to: `libs/LSPD First Response.dll`

## Why These Files Are Needed

- **RagePluginHook.exe**: Contains the Rage API for GTA V modding
- **LSPD First Response.dll**: Contains the LSPDFR API for police plugins

## Build Process

The build system will look for references in this order:
1. GTA5Dir environment variable location (preferred)
2. Auto-detected GTA V installations
3. Local libs folder (fallback)

## Legal Notice

These files are copyrighted by their respective owners:
- RagePluginHook: Rage Audio
- LSPD First Response: G17 Media

Only copy these files if you have legally obtained them through proper installation of GTA V, RagePluginHook, and LSPDFR.

## Alternative

Instead of copying files here, set the GTA5Dir environment variable:

```cmd
set GTA5Dir=C:\Program Files (x86)\Steam\steamapps\common\Grand Theft Auto V
```

This is the preferred method as it ensures you're always using the latest versions.
