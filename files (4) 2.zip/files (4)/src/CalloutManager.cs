using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Rage;
using LSPD_First_Response.Mod.API;

namespace LSPDNextGen
{
    /// <summary>
    /// Manages callout operations, assignments, and tracking
    /// </summary>
    public class CalloutManager
    {
        private readonly string _calloutsDataPath;
        private readonly string _activeCalloutsPath;
        private List<CalloutRecord> _callouts;
        private List<CalloutRecord> _activeCallouts;

        public CalloutManager()
        {
            _calloutsDataPath = Path.Combine(DataBootstrapper.GetDataPath("Callouts"), "callouts.json");
            _activeCalloutsPath = Path.Combine(DataBootstrapper.GetDataPath("Callouts"), "active_callouts.json");
            
            LoadCallouts();
            InitializeEventHandlers();
        }

        /// <summary>
        /// Gets all active callouts
        /// </summary>
        public List<CalloutRecord> GetActiveCallouts()
        {
            return _activeCallouts.ToList();
        }

        /// <summary>
        /// Gets callout history
        /// </summary>
        public List<CalloutRecord> GetCalloutHistory(int maxRecords = 50)
        {
            return _callouts.OrderByDescending(c => DateTime.Parse(c.Created)).Take(maxRecords).ToList();
        }

        /// <summary>
        /// Finds a callout by ID
        /// </summary>
        public CalloutRecord FindCallout(string calloutId)
        {
            var active = _activeCallouts.FirstOrDefault(c => c.CalloutId.Equals(calloutId, StringComparison.OrdinalIgnoreCase));
            if (active != null) return active;

            return _callouts.FirstOrDefault(c => c.CalloutId.Equals(calloutId, StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>
        /// Creates a new callout
        /// </summary>
        public string CreateCallout(string type, string description, Vector3 location, string address = "", CalloutPriority priority = CalloutPriority.Medium)
        {
            try
            {
                var callout = new CalloutRecord
                {
                    CalloutId = GenerateCalloutId(),
                    Type = type,
                    Priority = priority.ToString(),
                    Status = "Open",
                    Location = new LocationInfo
                    {
                        Address = address,
                        Zone = GetZoneName(location),
                        Coordinates = new Coordinates
                        {
                            X = location.X,
                            Y = location.Y,
                            Z = location.Z
                        }
                    },
                    Description = description,
                    AssignedOfficers = new List<string>(),
                    ResponseTime = null,
                    CompletionTime = null,
                    Evidence = new List<string>(),
                    Suspects = new List<string>(),
                    Witnesses = new List<string>(),
                    Notes = "",
                    Created = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                    LastUpdated = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };

                _activeCallouts.Add(callout);
                SaveActiveCallouts();

                Game.LogTrivial($"LSPD NextGen: Created callout {callout.CalloutId} - {type}");
                Game.DisplayNotification($"~y~New Callout~w~\n{type}\n{address}");

                return callout.CalloutId;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error creating callout: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// Assigns an officer to a callout
        /// </summary>
        public bool AssignOfficer(string calloutId, string officerBadge)
        {
            try
            {
                var callout = _activeCallouts.FirstOrDefault(c => c.CalloutId.Equals(calloutId, StringComparison.OrdinalIgnoreCase));
                if (callout == null)
                {
                    Game.LogTrivial($"LSPD NextGen: Active callout {calloutId} not found");
                    return false;
                }

                if (!callout.AssignedOfficers.Contains(officerBadge))
                {
                    callout.AssignedOfficers.Add(officerBadge);
                    callout.LastUpdated = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                    if (callout.Status == "Open")
                    {
                        callout.Status = "Assigned";
                        callout.ResponseTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    }

                    SaveActiveCallouts();
                    Game.LogTrivial($"LSPD NextGen: Assigned officer {officerBadge} to callout {calloutId}");
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error assigning officer to callout: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Updates callout status
        /// </summary>
        public bool UpdateCalloutStatus(string calloutId, string status, string notes = "")
        {
            try
            {
                var callout = _activeCallouts.FirstOrDefault(c => c.CalloutId.Equals(calloutId, StringComparison.OrdinalIgnoreCase));
                if (callout == null)
                {
                    Game.LogTrivial($"LSPD NextGen: Active callout {calloutId} not found");
                    return false;
                }

                var oldStatus = callout.Status;
                callout.Status = status;
                callout.LastUpdated = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                if (!string.IsNullOrEmpty(notes))
                {
                    if (!string.IsNullOrEmpty(callout.Notes))
                        callout.Notes += "\n";
                    callout.Notes += $"[{DateTime.Now:HH:mm:ss}] {notes}";
                }

                // Handle status-specific actions
                switch (status.ToLower())
                {
                    case "en route":
                        if (string.IsNullOrEmpty(callout.ResponseTime))
                            callout.ResponseTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        break;

                    case "on scene":
                        // Record arrival time if not already set
                        break;

                    case "completed":
                    case "closed":
                        callout.CompletionTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        CompleteCallout(calloutId);
                        break;

                    case "cancelled":
                        callout.CompletionTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        CompleteCallout(calloutId);
                        break;
                }

                SaveActiveCallouts();
                Game.LogTrivial($"LSPD NextGen: Updated callout {calloutId} status from {oldStatus} to {status}");
                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error updating callout status: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Adds evidence to a callout
        /// </summary>
        public bool AddEvidence(string calloutId, string evidence)
        {
            try
            {
                var callout = FindCallout(calloutId);
                if (callout == null) return false;

                callout.Evidence.Add($"[{DateTime.Now:HH:mm:ss}] {evidence}");
                callout.LastUpdated = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                SaveActiveCallouts();
                Game.LogTrivial($"LSPD NextGen: Added evidence to callout {calloutId}");
                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error adding evidence: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Adds a suspect to a callout
        /// </summary>
        public bool AddSuspect(string calloutId, string suspectInfo)
        {
            try
            {
                var callout = FindCallout(calloutId);
                if (callout == null) return false;

                callout.Suspects.Add(suspectInfo);
                callout.LastUpdated = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                SaveActiveCallouts();
                Game.LogTrivial($"LSPD NextGen: Added suspect to callout {calloutId}");
                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error adding suspect: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Adds a witness to a callout
        /// </summary>
        public bool AddWitness(string calloutId, string witnessInfo)
        {
            try
            {
                var callout = FindCallout(calloutId);
                if (callout == null) return false;

                callout.Witnesses.Add(witnessInfo);
                callout.LastUpdated = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                SaveActiveCallouts();
                Game.LogTrivial($"LSPD NextGen: Added witness to callout {calloutId}");
                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error adding witness: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Gets callouts by type
        /// </summary>
        public List<CalloutRecord> GetCalloutsByType(string type)
        {
            return _callouts.Where(c => c.Type.Contains(type, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        /// <summary>
        /// Gets callouts for a specific officer
        /// </summary>
        public List<CalloutRecord> GetCalloutsByOfficer(string officerBadge)
        {
            return _callouts.Where(c => c.AssignedOfficers.Contains(officerBadge)).ToList();
        }

        /// <summary>
        /// Gets callouts by priority level
        /// </summary>
        public List<CalloutRecord> GetCalloutsByPriority(CalloutPriority priority)
        {
            return _activeCallouts.Where(c => c.Priority.Equals(priority.ToString(), StringComparison.OrdinalIgnoreCase)).ToList();
        }

        /// <summary>
        /// Completes a callout and moves it to history
        /// </summary>
        private void CompleteCallout(string calloutId)
        {
            try
            {
                var callout = _activeCallouts.FirstOrDefault(c => c.CalloutId.Equals(calloutId, StringComparison.OrdinalIgnoreCase));
                if (callout == null) return;

                // Move to history
                _callouts.Add(callout);
                _activeCallouts.Remove(callout);

                SaveCallouts();
                SaveActiveCallouts();

                Game.LogTrivial($"LSPD NextGen: Completed callout {calloutId}");
                Game.DisplayNotification($"~g~Callout Completed~w~\n{callout.Type}\n{callout.CalloutId}");
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error completing callout: {ex.Message}");
            }
        }

        /// <summary>
        /// Generates a unique callout ID
        /// </summary>
        private string GenerateCalloutId()
        {
            var date = DateTime.Now.ToString("yyyyMMdd");
            var random = new Random();
            var sequence = random.Next(1000, 9999);
            return $"CALL{date}{sequence}";
        }

        /// <summary>
        /// Gets zone name from coordinates
        /// </summary>
        private string GetZoneName(Vector3 location)
        {
            try
            {
                // Use RAGE's built-in zone detection if available
                return World.GetZoneNameAtPosition(location) ?? "Unknown";
            }
            catch
            {
                return "Unknown";
            }
        }

        /// <summary>
        /// Initializes LSPDFR event handlers
        /// </summary>
        private void InitializeEventHandlers()
        {
            try
            {
                // Hook into LSPDFR events if available
                // This would typically involve registering for callout events
                Game.LogTrivial("LSPD NextGen: Callout event handlers initialized");
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error initializing event handlers: {ex.Message}");
            }
        }

        /// <summary>
        /// Loads callout data from files
        /// </summary>
        private void LoadCallouts()
        {
            try
            {
                _callouts = JsonFileHelper.ReadFromFile<List<CalloutRecord>>(_calloutsDataPath, true) ?? new List<CalloutRecord>();
                _activeCallouts = JsonFileHelper.ReadFromFile<List<CalloutRecord>>(_activeCalloutsPath, true) ?? new List<CalloutRecord>();

                Game.LogTrivial($"LSPD NextGen: Loaded {_callouts.Count} callout records and {_activeCallouts.Count} active callouts");
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error loading callouts: {ex.Message}");
                _callouts = new List<CalloutRecord>();
                _activeCallouts = new List<CalloutRecord>();
            }
        }

        /// <summary>
        /// Saves callout history to file
        /// </summary>
        private void SaveCallouts()
        {
            JsonFileHelper.WriteToFile(_calloutsDataPath, _callouts);
        }

        /// <summary>
        /// Saves active callouts to file
        /// </summary>
        private void SaveActiveCallouts()
        {
            JsonFileHelper.WriteToFile(_activeCalloutsPath, _activeCallouts);
        }

        /// <summary>
        /// Cleanup method
        /// </summary>
        public void Cleanup()
        {
            try
            {
                // Save any pending data
                SaveCallouts();
                SaveActiveCallouts();

                Game.LogTrivial("LSPD NextGen: Callout manager cleanup completed");
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error during callout manager cleanup: {ex.Message}");
            }
        }
    }

    /// <summary>
    /// Represents a callout record
    /// </summary>
    public class CalloutRecord
    {
        public string CalloutId { get; set; } = "";
        public string Type { get; set; } = "";
        public string Priority { get; set; } = "Medium";
        public string Status { get; set; } = "Open";
        public LocationInfo Location { get; set; } = new LocationInfo();
        public string Description { get; set; } = "";
        public List<string> AssignedOfficers { get; set; } = new List<string>();
        public string ResponseTime { get; set; } = "";
        public string CompletionTime { get; set; } = "";
        public List<string> Evidence { get; set; } = new List<string>();
        public List<string> Suspects { get; set; } = new List<string>();
        public List<string> Witnesses { get; set; } = new List<string>();
        public string Notes { get; set; } = "";
        public string Created { get; set; } = "";
        public string LastUpdated { get; set; } = "";
    }

    /// <summary>
    /// Location information for callouts
    /// </summary>
    public class LocationInfo
    {
        public string Address { get; set; } = "";
        public string Zone { get; set; } = "";
        public Coordinates Coordinates { get; set; } = new Coordinates();
    }

    /// <summary>
    /// 3D coordinates
    /// </summary>
    public class Coordinates
    {
        public float X { get; set; } = 0;
        public float Y { get; set; } = 0;
        public float Z { get; set; } = 0;
    }

    /// <summary>
    /// Callout priority levels
    /// </summary>
    public enum CalloutPriority
    {
        Low,
        Medium,
        High,
        Emergency
    }
}
