using System;
using System.IO;
using Rage;

namespace LSPDNextGen
{
    /// <summary>
    /// Handles initial data setup and directory structure creation
    /// </summary>
    public static class DataBootstrapper
    {
        private static readonly string BaseDataPath = "lspdfr/data/LSPDNextGen";
        private static readonly string ConfigPath = "plugins";
        
        public static void Initialize()
        {
            try
            {
                Game.LogTrivial("LSPD NextGen: Bootstrapping data systems...");
                
                CreateDirectoryStructure();
                CreateDefaultConfigFiles();
                CreateDefaultDataFiles();
                
                Game.LogTrivial("LSPD NextGen: Data bootstrapping completed successfully!");
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error during data bootstrapping: {ex.Message}");
                throw;
            }
        }

        private static void CreateDirectoryStructure()
        {
            try
            {
                var directories = new[]
                {
                    BaseDataPath,
                    Path.Combine(BaseDataPath, "Officers"),
                    Path.Combine(BaseDataPath, "Callouts"),
                    Path.Combine(BaseDataPath, "Reports"),
                    Path.Combine(BaseDataPath, "Suspects"),
                    Path.Combine(BaseDataPath, "Vehicles"),
                    Path.Combine(BaseDataPath, "Templates"),
                    Path.Combine(BaseDataPath, "Backup")
                };

                foreach (var directory in directories)
                {
                    if (!Directory.Exists(directory))
                    {
                        Directory.CreateDirectory(directory);
                        Game.LogTrivial($"LSPD NextGen: Created directory: {directory}");
                    }
                }
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error creating directory structure: {ex.Message}");
                throw;
            }
        }

        private static void CreateDefaultConfigFiles()
        {
            try
            {
                var configFile = Path.Combine(ConfigPath, "LSPDNextGen.ini");
                
                if (!File.Exists(configFile))
                {
                    var defaultConfig = @"[General]
OpenComputerKey=F7
Theme=Dark
AutoSave=true
BackupInterval=30

[Integrations]
EnableGrammarPolice=true
EnableStopThePed=true
EnableAlpr=true
EnableComputerPlus=false

[Database]
AutoCleanup=true
MaxRecords=10000
CleanupDays=30

[Reports]
AutoSaveReports=true
IncludeScreenshots=false
DefaultTemplate=Standard

[UI]
FontSize=12
ShowNotifications=true
PlaySounds=true
AnimateTransitions=true

[Performance]
CacheSize=100
RefreshInterval=5
AsyncOperations=true";

                    File.WriteAllText(configFile, defaultConfig);
                    Game.LogTrivial($"LSPD NextGen: Created default config file: {configFile}");
                }
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error creating config files: {ex.Message}");
                throw;
            }
        }

        private static void CreateDefaultDataFiles()
        {
            try
            {
                CreateDefaultOfficerTemplates();
                CreateDefaultCalloutTemplates();
                CreateDefaultReportTemplates();
                CreateSampleSuspectData();
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error creating default data files: {ex.Message}");
                throw;
            }
        }

        private static void CreateDefaultOfficerTemplates()
        {
            var templatePath = Path.Combine(BaseDataPath, "Templates", "officer_template.json");
            
            if (!File.Exists(templatePath))
            {
                var template = @"{
  ""Name"": """",
  ""BadgeNumber"": """",
  ""Rank"": ""Officer"",
  ""Department"": ""LSPD"",
  ""Division"": ""Patrol"",
  ""Shift"": ""Day"",
  ""Experience"": 0,
  ""Certifications"": [],
  ""ContactInfo"": {
    ""Radio"": """",
    ""Phone"": """",
    ""Email"": """"
  },
  ""Status"": ""Available"",
  ""Location"": """",
  ""Vehicle"": """",
  ""Partner"": """",
  ""Created"": """",
  ""LastActive"": """"
}";
                File.WriteAllText(templatePath, template);
                Game.LogTrivial("LSPD NextGen: Created officer template");
            }
        }

        private static void CreateDefaultCalloutTemplates()
        {
            var templatePath = Path.Combine(BaseDataPath, "Templates", "callout_template.json");
            
            if (!File.Exists(templatePath))
            {
                var template = @"{
  ""CalloutId"": """",
  ""Type"": """",
  ""Priority"": ""Medium"",
  ""Status"": ""Open"",
  ""Location"": {
    ""Address"": """",
    ""Zone"": """",
    ""Coordinates"": {
      ""X"": 0,
      ""Y"": 0,
      ""Z"": 0
    }
  },
  ""Description"": """",
  ""AssignedOfficers"": [],
  ""ResponseTime"": null,
  ""CompletionTime"": null,
  ""Evidence"": [],
  ""Suspects"": [],
  ""Witnesses"": [],
  ""Notes"": """",
  ""Created"": """",
  ""LastUpdated"": """"
}";
                File.WriteAllText(templatePath, template);
                Game.LogTrivial("LSPD NextGen: Created callout template");
            }
        }

        private static void CreateDefaultReportTemplates()
        {
            var templatePath = Path.Combine(BaseDataPath, "Templates", "report_template.json");
            
            if (!File.Exists(templatePath))
            {
                var template = @"{
  ""ReportId"": """",
  ""Type"": ""Incident Report"",
  ""Title"": """",
  ""OfficerInCharge"": """",
  ""AssistingOfficers"": [],
  ""DateTime"": """",
  ""Location"": {
    ""Address"": """",
    ""Zone"": """",
    ""Coordinates"": {
      ""X"": 0,
      ""Y"": 0,
      ""Z"": 0
    }
  },
  ""Summary"": """",
  ""Details"": """",
  ""InvolvedPersons"": [],
  ""Evidence"": [],
  ""Witnesses"": [],
  ""Charges"": [],
  ""Disposition"": """",
  ""FollowUpRequired"": false,
  ""Approved"": false,
  ""ApprovedBy"": """",
  ""Created"": """",
  ""LastModified"": """"
}";
                File.WriteAllText(templatePath, template);
                Game.LogTrivial("LSPD NextGen: Created report template");
            }
        }

        private static void CreateSampleSuspectData()
        {
            var samplePath = Path.Combine(BaseDataPath, "Suspects", "sample_suspects.json");
            
            if (!File.Exists(samplePath))
            {
                var sampleData = @"[
  {
    ""Id"": ""SUSP001"",
    ""FirstName"": ""John"",
    ""LastName"": ""Doe"",
    ""DateOfBirth"": ""1985-03-15"",
    ""Gender"": ""Male"",
    ""Race"": ""White"",
    ""Height"": ""5'10"",
    ""Weight"": ""180"",
    ""EyeColor"": ""Brown"",
    ""HairColor"": ""Black"",
    ""Address"": ""123 Sample St, Los Santos"",
    ""Phone"": ""555-0123"",
    ""Warrants"": [],
    ""PriorArrests"": [],
    ""KnownAssociates"": [],
    ""Gang"": """",
    ""Notes"": ""Sample suspect for testing"",
    ""DangerLevel"": ""Low"",
    ""LastSeen"": """",
    ""Created"": """",
    ""LastUpdated"": """"
  }
]";
                File.WriteAllText(samplePath, sampleData);
                Game.LogTrivial("LSPD NextGen: Created sample suspect data");
            }
        }

        public static string GetDataPath(string subPath = "")
        {
            return string.IsNullOrEmpty(subPath) ? BaseDataPath : Path.Combine(BaseDataPath, subPath);
        }

        public static bool VerifyDataIntegrity()
        {
            try
            {
                var requiredDirectories = new[]
                {
                    BaseDataPath,
                    Path.Combine(BaseDataPath, "Officers"),
                    Path.Combine(BaseDataPath, "Callouts"),
                    Path.Combine(BaseDataPath, "Reports"),
                    Path.Combine(BaseDataPath, "Suspects")
                };

                foreach (var directory in requiredDirectories)
                {
                    if (!Directory.Exists(directory))
                    {
                        Game.LogTrivial($"LSPD NextGen: Missing directory: {directory}");
                        return false;
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error verifying data integrity: {ex.Message}");
                return false;
            }
        }
    }
}
