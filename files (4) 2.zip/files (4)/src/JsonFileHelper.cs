using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using Rage;

namespace LSPDNextGen
{
    /// <summary>
    /// Utility class for handling JSON file operations with error handling and backup functionality
    /// </summary>
    public static class JsonFileHelper
    {
        private static readonly JsonSerializerSettings DefaultSettings = new JsonSerializerSettings
        {
            Formatting = Formatting.Indented,
            NullValueHandling = NullValueHandling.Ignore,
            DateFormatString = "yyyy-MM-dd HH:mm:ss"
        };

        /// <summary>
        /// Reads and deserializes a JSON file to the specified type
        /// </summary>
        /// <typeparam name="T">Type to deserialize to</typeparam>
        /// <param name="filePath">Path to the JSON file</param>
        /// <param name="createIfNotExists">Whether to create the file with default value if it doesn't exist</param>
        /// <returns>Deserialized object or default value</returns>
        public static T ReadFromFile<T>(string filePath, bool createIfNotExists = false) where T : new()
        {
            try
            {
                if (!File.Exists(filePath))
                {
                    if (createIfNotExists)
                    {
                        var defaultValue = new T();
                        WriteToFile(filePath, defaultValue);
                        return defaultValue;
                    }
                    
                    Game.LogTrivial($"LSPD NextGen: JSON file not found: {filePath}");
                    return default(T);
                }

                var jsonContent = File.ReadAllText(filePath);
                
                if (string.IsNullOrWhiteSpace(jsonContent))
                {
                    Game.LogTrivial($"LSPD NextGen: JSON file is empty: {filePath}");
                    return new T();
                }

                var result = JsonConvert.DeserializeObject<T>(jsonContent, DefaultSettings);
                return result ?? new T();
            }
            catch (JsonException jsonEx)
            {
                Game.LogTrivial($"LSPD NextGen: JSON parsing error in {filePath}: {jsonEx.Message}");
                
                // Try to restore from backup if available
                var backupPath = GetBackupPath(filePath);
                if (File.Exists(backupPath))
                {
                    Game.LogTrivial($"LSPD NextGen: Attempting to restore from backup: {backupPath}");
                    return ReadFromBackup<T>(backupPath);
                }
                
                return new T();
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error reading JSON file {filePath}: {ex.Message}");
                return new T();
            }
        }

        /// <summary>
        /// Serializes and writes an object to a JSON file with backup functionality
        /// </summary>
        /// <typeparam name="T">Type of object to serialize</typeparam>
        /// <param name="filePath">Path to write the JSON file</param>
        /// <param name="data">Object to serialize</param>
        /// <param name="createBackup">Whether to create a backup before writing</param>
        /// <returns>True if successful, false otherwise</returns>
        public static bool WriteToFile<T>(string filePath, T data, bool createBackup = true)
        {
            try
            {
                // Create directory if it doesn't exist
                var directory = Path.GetDirectoryName(filePath);
                if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                // Create backup if file exists and backup is requested
                if (createBackup && File.Exists(filePath))
                {
                    CreateBackup(filePath);
                }

                // Serialize and write to temporary file first
                var tempPath = filePath + ".tmp";
                var jsonContent = JsonConvert.SerializeObject(data, DefaultSettings);
                File.WriteAllText(tempPath, jsonContent);

                // Replace original file with temporary file (atomic operation)
                if (File.Exists(filePath))
                {
                    File.Delete(filePath);
                }
                File.Move(tempPath, filePath);

                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error writing JSON file {filePath}: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Appends data to a JSON array file
        /// </summary>
        /// <typeparam name="T">Type of object to append</typeparam>
        /// <param name="filePath">Path to the JSON array file</param>
        /// <param name="newItem">Item to append</param>
        /// <returns>True if successful, false otherwise</returns>
        public static bool AppendToJsonArray<T>(string filePath, T newItem)
        {
            try
            {
                var existingData = ReadFromFile<T[]>(filePath, true);
                var list = existingData?.ToList() ?? new List<T>();
                list.Add(newItem);
                
                return WriteToFile(filePath, list.ToArray());
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error appending to JSON array {filePath}: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Updates an item in a JSON array file based on a predicate
        /// </summary>
        /// <typeparam name="T">Type of object in the array</typeparam>
        /// <param name="filePath">Path to the JSON array file</param>
        /// <param name="predicate">Function to find the item to update</param>
        /// <param name="updatedItem">New item to replace the found item</param>
        /// <returns>True if item was found and updated, false otherwise</returns>
        public static bool UpdateInJsonArray<T>(string filePath, Func<T, bool> predicate, T updatedItem)
        {
            try
            {
                var existingData = ReadFromFile<T[]>(filePath);
                if (existingData == null) return false;

                var list = existingData.ToList();
                var index = list.FindIndex(item => predicate(item));
                
                if (index >= 0)
                {
                    list[index] = updatedItem;
                    return WriteToFile(filePath, list.ToArray());
                }

                return false;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error updating JSON array {filePath}: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Removes an item from a JSON array file based on a predicate
        /// </summary>
        /// <typeparam name="T">Type of object in the array</typeparam>
        /// <param name="filePath">Path to the JSON array file</param>
        /// <param name="predicate">Function to find the item to remove</param>
        /// <returns>True if item was found and removed, false otherwise</returns>
        public static bool RemoveFromJsonArray<T>(string filePath, Func<T, bool> predicate)
        {
            try
            {
                var existingData = ReadFromFile<T[]>(filePath);
                if (existingData == null) return false;

                var list = existingData.ToList();
                var itemsToRemove = list.Where(predicate).ToList();
                
                if (itemsToRemove.Any())
                {
                    foreach (var item in itemsToRemove)
                    {
                        list.Remove(item);
                    }
                    return WriteToFile(filePath, list.ToArray());
                }

                return false;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error removing from JSON array {filePath}: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Creates a backup of the specified file
        /// </summary>
        /// <param name="filePath">Path to the file to backup</param>
        private static void CreateBackup(string filePath)
        {
            try
            {
                if (!File.Exists(filePath)) return;

                var backupPath = GetBackupPath(filePath);
                var backupDir = Path.GetDirectoryName(backupPath);
                
                if (!Directory.Exists(backupDir))
                {
                    Directory.CreateDirectory(backupDir);
                }

                File.Copy(filePath, backupPath, true);
                Game.LogTrivial($"LSPD NextGen: Created backup: {backupPath}");
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error creating backup for {filePath}: {ex.Message}");
            }
        }

        /// <summary>
        /// Reads data from a backup file
        /// </summary>
        /// <typeparam name="T">Type to deserialize to</typeparam>
        /// <param name="backupPath">Path to the backup file</param>
        /// <returns>Deserialized object or default value</returns>
        private static T ReadFromBackup<T>(string backupPath) where T : new()
        {
            try
            {
                var jsonContent = File.ReadAllText(backupPath);
                return JsonConvert.DeserializeObject<T>(jsonContent, DefaultSettings) ?? new T();
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error reading backup {backupPath}: {ex.Message}");
                return new T();
            }
        }

        /// <summary>
        /// Gets the backup path for a given file
        /// </summary>
        /// <param name="filePath">Original file path</param>
        /// <returns>Backup file path</returns>
        private static string GetBackupPath(string filePath)
        {
            var directory = Path.GetDirectoryName(filePath);
            var filename = Path.GetFileNameWithoutExtension(filePath);
            var extension = Path.GetExtension(filePath);
            var timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            
            var backupDir = Path.Combine(directory, "Backup");
            return Path.Combine(backupDir, $"{filename}_{timestamp}{extension}");
        }

        /// <summary>
        /// Validates if a file contains valid JSON
        /// </summary>
        /// <param name="filePath">Path to the JSON file</param>
        /// <returns>True if valid JSON, false otherwise</returns>
        public static bool IsValidJson(string filePath)
        {
            try
            {
                if (!File.Exists(filePath)) return false;

                var content = File.ReadAllText(filePath);
                JsonConvert.DeserializeObject(content);
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Cleans up old backup files (keeps only the most recent ones)
        /// </summary>
        /// <param name="backupDirectory">Directory containing backup files</param>
        /// <param name="maxBackups">Maximum number of backups to keep per file</param>
        public static void CleanupOldBackups(string backupDirectory, int maxBackups = 5)
        {
            try
            {
                if (!Directory.Exists(backupDirectory)) return;

                var backupFiles = Directory.GetFiles(backupDirectory, "*.json")
                    .GroupBy(f => Path.GetFileNameWithoutExtension(f).Split('_')[0])
                    .ToList();

                foreach (var group in backupFiles)
                {
                    var files = group.OrderByDescending(f => File.GetCreationTime(f)).ToList();
                    
                    // Delete excess backup files
                    for (int i = maxBackups; i < files.Count; i++)
                    {
                        File.Delete(files[i]);
                        Game.LogTrivial($"LSPD NextGen: Deleted old backup: {files[i]}");
                    }
                }
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error cleaning up backups: {ex.Message}");
            }
        }
    }
}
