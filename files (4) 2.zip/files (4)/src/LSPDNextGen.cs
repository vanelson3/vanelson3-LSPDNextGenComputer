using System;
using System.Windows.Forms;
using Rage;
using LSPD_First_Response.Mod.API;
using LSPD_First_Response.Mod.Callouts;

[assembly: Rage.Attributes.Plugin("LSPD NextGen", Description = "Next Generation LSPD Computer System", Author = "vanelson3")]

namespace LSPDNextGen
{
    /// <summary>
    /// Main plugin entry point for LSPD NextGen
    /// </summary>
    public class LSPDNextGen : Plugin
    {
        private static bool _isInitialized = false;
        private static Keys _computerKey = Keys.F7;
        private static string _theme = "Dark";
        
        // Core managers
        private static OfficerManager _officerManager;
        private static CalloutManager _calloutManager;
        private static ReportManager _reportManager;
        private static SuspectDatabase _suspectDatabase;

        public override void Initialize()
        {
            try
            {
                Game.LogTrivial("LSPD NextGen: Initializing plugin...");
                
                // Initialize configuration
                LoadConfiguration();
                
                // Bootstrap data systems
                DataBootstrapper.Initialize();
                
                // Initialize core managers
                _officerManager = new OfficerManager();
                _calloutManager = new CalloutManager();
                _reportManager = new ReportManager();
                _suspectDatabase = new SuspectDatabase();
                
                // Register for LSPDFR events
                Functions.OnOnDutyStateChanged += OnDutyStateChanged;
                
                Game.LogTrivial("LSPD NextGen: Plugin initialized successfully!");
                _isInitialized = true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error during initialization: {ex.Message}");
                Game.DisplayNotification("LSPD NextGen failed to initialize. Check logs for details.");
            }
        }

        public override void Finally()
        {
            try
            {
                Game.LogTrivial("LSPD NextGen: Cleaning up...");
                
                // Unregister events
                Functions.OnOnDutyStateChanged -= OnDutyStateChanged;
                
                // Cleanup managers
                _officerManager?.Cleanup();
                _calloutManager?.Cleanup();
                _reportManager?.Cleanup();
                _suspectDatabase?.Cleanup();
                
                Game.LogTrivial("LSPD NextGen: Plugin cleanup completed.");
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error during cleanup: {ex.Message}");
            }
        }

        private static void LoadConfiguration()
        {
            try
            {
                var configPath = "plugins/LSPD First Response/LSPDNextGen.ini";
                var ini = new InitializationFile(configPath);
                
                // Load general settings
                var computerKeyString = ini.ReadValue("General", "OpenComputerKey", "F7");
                if (Enum.TryParse(computerKeyString, out Keys key))
                {
                    _computerKey = key;
                }
                
                _theme = ini.ReadValue("General", "Theme", "Dark");
                
                // Load integration settings
                var enableGrammarPolice = ini.ReadBoolean("Integrations", "EnableGrammarPolice", true);
                var enableStopThePed = ini.ReadBoolean("Integrations", "EnableStopThePed", true);
                
                Game.LogTrivial($"LSPD NextGen: Configuration loaded. Computer key: {_computerKey}, Theme: {_theme}");
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error loading configuration: {ex.Message}");
            }
        }

        private static void OnDutyStateChanged(bool onDuty)
        {
            try
            {
                if (onDuty)
                {
                    Game.LogTrivial("LSPD NextGen: Officer went on duty");
                    StartMainLoop();
                }
                else
                {
                    Game.LogTrivial("LSPD NextGen: Officer went off duty");
                }
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error in OnDutyStateChanged: {ex.Message}");
            }
        }

        private static void StartMainLoop()
        {
            GameFiber.StartNew(() =>
            {
                try
                {
                    while (_isInitialized && Game.IsKeyDown(_computerKey))
                    {
                        if (Game.IsKeyDownRightNow(_computerKey))
                        {
                            OpenComputerSystem();
                            GameFiber.Sleep(1000); // Prevent spam
                        }
                        GameFiber.Yield();
                    }
                }
                catch (Exception ex)
                {
                    Game.LogTrivial($"LSPD NextGen: Error in main loop: {ex.Message}");
                }
            });
        }

        private static void OpenComputerSystem()
        {
            try
            {
                Game.LogTrivial("LSPD NextGen: Opening computer system");
                Game.DisplayNotification("~b~LSPD NextGen~w~\nComputer system opened");
                
                // Here you would open your computer UI
                // For now, just show available functions
                ShowAvailableFunctions();
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error opening computer system: {ex.Message}");
            }
        }

        private static void ShowAvailableFunctions()
        {
            try
            {
                Game.DisplaySubtitle("LSPD NextGen Computer System\n" +
                                   "Officer Management | Callout System | Report Generator | Suspect Database", 5000);
                
                // Example usage of managers
                var currentOfficer = _officerManager.GetCurrentOfficer();
                if (currentOfficer != null)
                {
                    Game.LogTrivial($"Current officer: {currentOfficer.Name} - {currentOfficer.BadgeNumber}");
                }
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error showing functions: {ex.Message}");
            }
        }

        // Public API for other plugins
        public static OfficerManager GetOfficerManager() => _officerManager;
        public static CalloutManager GetCalloutManager() => _calloutManager;
        public static ReportManager GetReportManager() => _reportManager;
        public static SuspectDatabase GetSuspectDatabase() => _suspectDatabase;
        public static bool IsInitialized => _isInitialized;
    }
}
