using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Rage;
using LSPD_First_Response.Mod.API;

namespace LSPDNextGen
{
    /// <summary>
    /// Manages officer data and operations
    /// </summary>
    public class OfficerManager
    {
        private readonly string _officersDataPath;
        private readonly List<Officer> _officers;
        private Officer _currentOfficer;

        public OfficerManager()
        {
            _officersDataPath = Path.Combine(DataBootstrapper.GetDataPath("Officers"), "officers.json");
            _officers = LoadOfficers();
            InitializeCurrentOfficer();
        }

        /// <summary>
        /// Gets the current officer on duty
        /// </summary>
        public Officer GetCurrentOfficer()
        {
            return _currentOfficer;
        }

        /// <summary>
        /// Gets all officers in the system
        /// </summary>
        public List<Officer> GetAllOfficers()
        {
            return _officers.ToList(); // Return copy to prevent external modification
        }

        /// <summary>
        /// Finds an officer by badge number
        /// </summary>
        public Officer FindOfficerByBadge(string badgeNumber)
        {
            return _officers.FirstOrDefault(o => o.BadgeNumber.Equals(badgeNumber, StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>
        /// Finds officers by name (partial match)
        /// </summary>
        public List<Officer> FindOfficersByName(string name)
        {
            return _officers.Where(o => o.Name.Contains(name, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        /// <summary>
        /// Adds a new officer to the system
        /// </summary>
        public bool AddOfficer(Officer officer)
        {
            try
            {
                if (string.IsNullOrEmpty(officer.BadgeNumber) || string.IsNullOrEmpty(officer.Name))
                {
                    Game.LogTrivial("LSPD NextGen: Cannot add officer - missing required fields");
                    return false;
                }

                if (FindOfficerByBadge(officer.BadgeNumber) != null)
                {
                    Game.LogTrivial($"LSPD NextGen: Officer with badge {officer.BadgeNumber} already exists");
                    return false;
                }

                officer.Created = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                officer.LastActive = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                _officers.Add(officer);
                SaveOfficers();

                Game.LogTrivial($"LSPD NextGen: Added officer {officer.Name} (Badge: {officer.BadgeNumber})");
                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error adding officer: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Updates an existing officer's information
        /// </summary>
        public bool UpdateOfficer(Officer updatedOfficer)
        {
            try
            {
                var existingOfficer = FindOfficerByBadge(updatedOfficer.BadgeNumber);
                if (existingOfficer == null)
                {
                    Game.LogTrivial($"LSPD NextGen: Officer with badge {updatedOfficer.BadgeNumber} not found");
                    return false;
                }

                // Preserve creation date
                updatedOfficer.Created = existingOfficer.Created;
                updatedOfficer.LastActive = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                var index = _officers.IndexOf(existingOfficer);
                _officers[index] = updatedOfficer;

                // Update current officer if it's the same one
                if (_currentOfficer?.BadgeNumber == updatedOfficer.BadgeNumber)
                {
                    _currentOfficer = updatedOfficer;
                }

                SaveOfficers();
                Game.LogTrivial($"LSPD NextGen: Updated officer {updatedOfficer.Name}");
                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error updating officer: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Removes an officer from the system
        /// </summary>
        public bool RemoveOfficer(string badgeNumber)
        {
            try
            {
                var officer = FindOfficerByBadge(badgeNumber);
                if (officer == null)
                {
                    Game.LogTrivial($"LSPD NextGen: Officer with badge {badgeNumber} not found");
                    return false;
                }

                _officers.Remove(officer);
                
                // Clear current officer if it's the one being removed
                if (_currentOfficer?.BadgeNumber == badgeNumber)
                {
                    _currentOfficer = null;
                }

                SaveOfficers();
                Game.LogTrivial($"LSPD NextGen: Removed officer {officer.Name}");
                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error removing officer: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Updates officer status (Available, Busy, Off-Duty, etc.)
        /// </summary>
        public bool UpdateOfficerStatus(string badgeNumber, string status, string location = "")
        {
            try
            {
                var officer = FindOfficerByBadge(badgeNumber);
                if (officer == null) return false;

                officer.Status = status;
                if (!string.IsNullOrEmpty(location))
                {
                    officer.Location = location;
                }
                officer.LastActive = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                SaveOfficers();
                Game.LogTrivial($"LSPD NextGen: Updated officer {officer.Name} status to {status}");
                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error updating officer status: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Gets officers by their current status
        /// </summary>
        public List<Officer> GetOfficersByStatus(string status)
        {
            return _officers.Where(o => o.Status.Equals(status, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        /// <summary>
        /// Gets officers by department
        /// </summary>
        public List<Officer> GetOfficersByDepartment(string department)
        {
            return _officers.Where(o => o.Department.Equals(department, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        /// <summary>
        /// Gets officers by division
        /// </summary>
        public List<Officer> GetOfficersByDivision(string division)
        {
            return _officers.Where(o => o.Division.Equals(division, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        /// <summary>
        /// Assigns a vehicle to an officer
        /// </summary>
        public bool AssignVehicle(string badgeNumber, string vehicleInfo)
        {
            try
            {
                var officer = FindOfficerByBadge(badgeNumber);
                if (officer == null) return false;

                officer.Vehicle = vehicleInfo;
                officer.LastActive = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                
                SaveOfficers();
                Game.LogTrivial($"LSPD NextGen: Assigned vehicle {vehicleInfo} to officer {officer.Name}");
                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error assigning vehicle: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Sets officer partner
        /// </summary>
        public bool SetPartner(string officerBadge, string partnerBadge)
        {
            try
            {
                var officer = FindOfficerByBadge(officerBadge);
                var partner = FindOfficerByBadge(partnerBadge);
                
                if (officer == null || partner == null) return false;

                officer.Partner = partner.Name + " (" + partner.BadgeNumber + ")";
                partner.Partner = officer.Name + " (" + officer.BadgeNumber + ")";
                
                officer.LastActive = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                partner.LastActive = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                SaveOfficers();
                Game.LogTrivial($"LSPD NextGen: Set partnership between {officer.Name} and {partner.Name}");
                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error setting partner: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Initializes the current officer based on the player
        /// </summary>
        private void InitializeCurrentOfficer()
        {
            try
            {
                // Try to find existing officer or create a new one
                var playerName = Game.LocalPlayer.Name ?? "Officer Player";
                var badgeNumber = GenerateBadgeNumber();

                _currentOfficer = _officers.FirstOrDefault(o => o.Name.Equals(playerName, StringComparison.OrdinalIgnoreCase));

                if (_currentOfficer == null)
                {
                    // Create new officer for the player
                    _currentOfficer = new Officer
                    {
                        Name = playerName,
                        BadgeNumber = badgeNumber,
                        Rank = "Officer",
                        Department = "LSPD",
                        Division = "Patrol",
                        Shift = GetCurrentShift(),
                        Experience = 0,
                        Certifications = new List<string>(),
                        ContactInfo = new ContactInfo
                        {
                            Radio = $"Unit-{badgeNumber}",
                            Phone = "",
                            Email = ""
                        },
                        Status = "On Duty",
                        Location = "",
                        Vehicle = "",
                        Partner = "",
                        Created = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                        LastActive = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                    };

                    AddOfficer(_currentOfficer);
                }
                else
                {
                    // Update last active time for existing officer
                    _currentOfficer.LastActive = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    _currentOfficer.Status = "On Duty";
                    SaveOfficers();
                }

                Game.LogTrivial($"LSPD NextGen: Current officer initialized: {_currentOfficer.Name} (Badge: {_currentOfficer.BadgeNumber})");
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error initializing current officer: {ex.Message}");
            }
        }

        /// <summary>
        /// Generates a unique badge number
        /// </summary>
        private string GenerateBadgeNumber()
        {
            var random = new Random();
            string badgeNumber;
            
            do
            {
                badgeNumber = random.Next(1000, 9999).ToString();
            } while (FindOfficerByBadge(badgeNumber) != null);

            return badgeNumber;
        }

        /// <summary>
        /// Determines current shift based on game time
        /// </summary>
        private string GetCurrentShift()
        {
            var hour = World.TimeOfDay.Hours;
            
            if (hour >= 6 && hour < 14)
                return "Day";
            else if (hour >= 14 && hour < 22)
                return "Evening";
            else
                return "Night";
        }

        /// <summary>
        /// Loads officers from the data file
        /// </summary>
        private List<Officer> LoadOfficers()
        {
            try
            {
                var officers = JsonFileHelper.ReadFromFile<List<Officer>>(_officersDataPath, true);
                Game.LogTrivial($"LSPD NextGen: Loaded {officers?.Count ?? 0} officers");
                return officers ?? new List<Officer>();
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error loading officers: {ex.Message}");
                return new List<Officer>();
            }
        }

        /// <summary>
        /// Saves officers to the data file
        /// </summary>
        private void SaveOfficers()
        {
            try
            {
                JsonFileHelper.WriteToFile(_officersDataPath, _officers);
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error saving officers: {ex.Message}");
            }
        }

        /// <summary>
        /// Cleanup method called when plugin is unloaded
        /// </summary>
        public void Cleanup()
        {
            try
            {
                // Update current officer status to off duty
                if (_currentOfficer != null)
                {
                    _currentOfficer.Status = "Off Duty";
                    _currentOfficer.LastActive = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    SaveOfficers();
                }

                Game.LogTrivial("LSPD NextGen: Officer manager cleanup completed");
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error during officer manager cleanup: {ex.Message}");
            }
        }
    }

    /// <summary>
    /// Represents an officer in the system
    /// </summary>
    public class Officer
    {
        public string Name { get; set; } = "";
        public string BadgeNumber { get; set; } = "";
        public string Rank { get; set; } = "Officer";
        public string Department { get; set; } = "LSPD";
        public string Division { get; set; } = "Patrol";
        public string Shift { get; set; } = "Day";
        public int Experience { get; set; } = 0;
        public List<string> Certifications { get; set; } = new List<string>();
        public ContactInfo ContactInfo { get; set; } = new ContactInfo();
        public string Status { get; set; } = "Available";
        public string Location { get; set; } = "";
        public string Vehicle { get; set; } = "";
        public string Partner { get; set; } = "";
        public string Created { get; set; } = "";
        public string LastActive { get; set; } = "";
    }

    /// <summary>
    /// Contact information for an officer
    /// </summary>
    public class ContactInfo
    {
        public string Radio { get; set; } = "";
        public string Phone { get; set; } = "";
        public string Email { get; set; } = "";
    }
}
