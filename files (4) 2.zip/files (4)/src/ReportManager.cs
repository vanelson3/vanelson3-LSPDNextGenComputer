using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Rage;

namespace LSPDNextGen
{
    /// <summary>
    /// Manages police report generation, templates, and storage
    /// </summary>
    public class ReportManager
    {
        private readonly string _reportsDataPath;
        private readonly string _templatesPath;
        private readonly string _draftReportsPath;
        private List<PoliceReport> _reports;
        private List<ReportTemplate> _templates;
        private List<PoliceReport> _draftReports;

        public ReportManager()
        {
            _reportsDataPath = Path.Combine(DataBootstrapper.GetDataPath("Reports"), "reports.json");
            _templatesPath = Path.Combine(DataBootstrapper.GetDataPath("Templates"), "report_templates.json");
            _draftReportsPath = Path.Combine(DataBootstrapper.GetDataPath("Reports"), "draft_reports.json");
            
            LoadReportData();
            InitializeDefaultTemplates();
        }

        /// <summary>
        /// Creates a new report from a template
        /// </summary>
        public string CreateReport(string templateName, string title, string officerBadge)
        {
            try
            {
                var template = _templates.FirstOrDefault(t => t.Name.Equals(templateName, StringComparison.OrdinalIgnoreCase));
                if (template == null)
                {
                    Game.LogTrivial($"LSPD NextGen: Report template '{templateName}' not found");
                    return null;
                }

                var report = new PoliceReport
                {
                    ReportId = GenerateReportId(),
                    Type = template.Type,
                    Title = title,
                    OfficerInCharge = officerBadge,
                    AssistingOfficers = new List<string>(),
                    DateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                    Location = new LocationInfo(),
                    Summary = "",
                    Details = template.DefaultContent,
                    InvolvedPersons = new List<InvolvedPerson>(),
                    Evidence = new List<EvidenceItem>(),
                    Witnesses = new List<Witness>(),
                    Charges = new List<Charge>(),
                    Disposition = "",
                    FollowUpRequired = false,
                    Approved = false,
                    ApprovedBy = "",
                    Created = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                    LastModified = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                    Status = "Draft"
                };

                _draftReports.Add(report);
                SaveDraftReports();

                Game.LogTrivial($"LSPD NextGen: Created report {report.ReportId} from template {templateName}");
                return report.ReportId;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error creating report: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// Gets a report by ID (checks both drafts and finalized reports)
        /// </summary>
        public PoliceReport GetReport(string reportId)
        {
            var draft = _draftReports.FirstOrDefault(r => r.ReportId.Equals(reportId, StringComparison.OrdinalIgnoreCase));
            if (draft != null) return draft;

            return _reports.FirstOrDefault(r => r.ReportId.Equals(reportId, StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>
        /// Updates an existing report
        /// </summary>
        public bool UpdateReport(PoliceReport updatedReport)
        {
            try
            {
                PoliceReport existingReport = null;
                List<PoliceReport> targetList = null;

                // Check drafts first
                existingReport = _draftReports.FirstOrDefault(r => r.ReportId.Equals(updatedReport.ReportId, StringComparison.OrdinalIgnoreCase));
                if (existingReport != null)
                {
                    targetList = _draftReports;
                }
                else
                {
                    // Check finalized reports
                    existingReport = _reports.FirstOrDefault(r => r.ReportId.Equals(updatedReport.ReportId, StringComparison.OrdinalIgnoreCase));
                    if (existingReport != null && !existingReport.Approved)
                    {
                        targetList = _reports;
                    }
                }

                if (existingReport == null || targetList == null)
                {
                    Game.LogTrivial($"LSPD NextGen: Report {updatedReport.ReportId} not found or cannot be modified");
                    return false;
                }

                // Preserve certain fields
                updatedReport.Created = existingReport.Created;
                updatedReport.LastModified = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                var index = targetList.IndexOf(existingReport);
                targetList[index] = updatedReport;

                if (targetList == _draftReports)
                    SaveDraftReports();
                else
                    SaveReports();

                Game.LogTrivial($"LSPD NextGen: Updated report {updatedReport.ReportId}");
                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error updating report: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Finalizes a draft report
        /// </summary>
        public bool FinalizeReport(string reportId)
        {
            try
            {
                var draftReport = _draftReports.FirstOrDefault(r => r.ReportId.Equals(reportId, StringComparison.OrdinalIgnoreCase));
                if (draftReport == null)
                {
                    Game.LogTrivial($"LSPD NextGen: Draft report {reportId} not found");
                    return false;
                }

                // Validate required fields
                if (string.IsNullOrEmpty(draftReport.Summary) || string.IsNullOrEmpty(draftReport.Details))
                {
                    Game.LogTrivial($"LSPD NextGen: Report {reportId} missing required fields");
                    return false;
                }

                draftReport.Status = "Submitted";
                draftReport.LastModified = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                // Move from drafts to reports
                _reports.Add(draftReport);
                _draftReports.Remove(draftReport);

                SaveReports();
                SaveDraftReports();

                Game.LogTrivial($"LSPD NextGen: Finalized report {reportId}");
                Game.DisplayNotification($"~g~Report Submitted~w~\n{reportId}");
                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error finalizing report: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Approves a report (supervisor function)
        /// </summary>
        public bool ApproveReport(string reportId, string approvingOfficer)
        {
            try
            {
                var report = _reports.FirstOrDefault(r => r.ReportId.Equals(reportId, StringComparison.OrdinalIgnoreCase));
                if (report == null)
                {
                    Game.LogTrivial($"LSPD NextGen: Report {reportId} not found");
                    return false;
                }

                if (report.Approved)
                {
                    Game.LogTrivial($"LSPD NextGen: Report {reportId} already approved");
                    return false;
                }

                report.Approved = true;
                report.ApprovedBy = approvingOfficer;
                report.Status = "Approved";
                report.LastModified = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                SaveReports();

                Game.LogTrivial($"LSPD NextGen: Approved report {reportId} by {approvingOfficer}");
                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error approving report: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Adds an involved person to a report
        /// </summary>
        public bool AddInvolvedPerson(string reportId, InvolvedPerson person)
        {
            try
            {
                var report = GetReport(reportId);
                if (report == null) return false;

                report.InvolvedPersons.Add(person);
                report.LastModified = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                UpdateReport(report);
                Game.LogTrivial($"LSPD NextGen: Added involved person to report {reportId}");
                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error adding involved person: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Adds evidence to a report
        /// </summary>
        public bool AddEvidence(string reportId, EvidenceItem evidence)
        {
            try
            {
                var report = GetReport(reportId);
                if (report == null) return false;

                evidence.CollectedBy = evidence.CollectedBy ?? report.OfficerInCharge;
                evidence.CollectedDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                report.Evidence.Add(evidence);
                report.LastModified = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                UpdateReport(report);
                Game.LogTrivial($"LSPD NextGen: Added evidence to report {reportId}");
                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error adding evidence: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Adds a witness to a report
        /// </summary>
        public bool AddWitness(string reportId, Witness witness)
        {
            try
            {
                var report = GetReport(reportId);
                if (report == null) return false;

                report.Witnesses.Add(witness);
                report.LastModified = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                UpdateReport(report);
                Game.LogTrivial($"LSPD NextGen: Added witness to report {reportId}");
                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error adding witness: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Adds charges to a report
        /// </summary>
        public bool AddCharge(string reportId, Charge charge)
        {
            try
            {
                var report = GetReport(reportId);
                if (report == null) return false;

                report.Charges.Add(charge);
                report.LastModified = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                UpdateReport(report);
                Game.LogTrivial($"LSPD NextGen: Added charge to report {reportId}");
                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error adding charge: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Gets reports by officer
        /// </summary>
        public List<PoliceReport> GetReportsByOfficer(string officerBadge)
        {
            var allReports = _reports.Concat(_draftReports);
            return allReports.Where(r => 
                r.OfficerInCharge.Equals(officerBadge, StringComparison.OrdinalIgnoreCase) ||
                r.AssistingOfficers.Contains(officerBadge)).ToList();
        }

        /// <summary>
        /// Gets reports by date range
        /// </summary>
        public List<PoliceReport> GetReportsByDateRange(DateTime startDate, DateTime endDate)
        {
            var allReports = _reports.Concat(_draftReports);
            return allReports.Where(r => 
            {
                if (DateTime.TryParse(r.DateTime, out DateTime reportDate))
                {
                    return reportDate >= startDate && reportDate <= endDate;
                }
                return false;
            }).ToList();
        }

        /// <summary>
        /// Gets reports by type
        /// </summary>
        public List<PoliceReport> GetReportsByType(string type)
        {
            var allReports = _reports.Concat(_draftReports);
            return allReports.Where(r => r.Type.Contains(type, StringComparison.OrdinalIgnoreCase)).ToList();
        }

        /// <summary>
        /// Gets pending reports (submitted but not approved)
        /// </summary>
        public List<PoliceReport> GetPendingReports()
        {
            return _reports.Where(r => !r.Approved && r.Status == "Submitted").ToList();
        }

        /// <summary>
        /// Gets draft reports
        /// </summary>
        public List<PoliceReport> GetDraftReports()
        {
            return _draftReports.ToList();
        }

        /// <summary>
        /// Generates a unique report ID
        /// </summary>
        private string GenerateReportId()
        {
            var date = DateTime.Now.ToString("yyyyMMdd");
            var random = new Random();
            var sequence = random.Next(1000, 9999);
            return $"RPT{date}{sequence}";
        }

        /// <summary>
        /// Initializes default report templates
        /// </summary>
        private void InitializeDefaultTemplates()
        {
            try
            {
                if (_templates.Count == 0)
                {
                    var defaultTemplates = new List<ReportTemplate>
                    {
                        new ReportTemplate
                        {
                            Name = "Incident Report",
                            Type = "Incident Report",
                            DefaultContent = "INCIDENT SUMMARY:\n\nNARRATIVE:\n\nACTIONS TAKEN:\n\nRECOMMENDATIONS:"
                        },
                        new ReportTemplate
                        {
                            Name = "Traffic Stop",
                            Type = "Traffic Citation",
                            DefaultContent = "REASON FOR STOP:\n\nVEHICLE INFORMATION:\n\nDRIVER INFORMATION:\n\nVIOLATIONS OBSERVED:\n\nCITATIONS ISSUED:"
                        },
                        new ReportTemplate
                        {
                            Name = "Arrest Report",
                            Type = "Arrest Report",
                            DefaultContent = "PROBABLE CAUSE:\n\nARREST DETAILS:\n\nSUSPECT INFORMATION:\n\nEVIDENCE COLLECTED:\n\nCHARGES:"
                        },
                        new ReportTemplate
                        {
                            Name = "Use of Force",
                            Type = "Use of Force Report",
                            DefaultContent = "INCIDENT DETAILS:\n\nFORCE USED:\n\nJUSTIFICATION:\n\nINJURIES:\n\nWITNESSES:"
                        }
                    };

                    _templates.AddRange(defaultTemplates);
                    SaveTemplates();
                    Game.LogTrivial("LSPD NextGen: Initialized default report templates");
                }
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error initializing templates: {ex.Message}");
            }
        }

        /// <summary>
        /// Loads all report data from files
        /// </summary>
        private void LoadReportData()
        {
            try
            {
                _reports = JsonFileHelper.ReadFromFile<List<PoliceReport>>(_reportsDataPath, true) ?? new List<PoliceReport>();
                _templates = JsonFileHelper.ReadFromFile<List<ReportTemplate>>(_templatesPath, true) ?? new List<ReportTemplate>();
                _draftReports = JsonFileHelper.ReadFromFile<List<PoliceReport>>(_draftReportsPath, true) ?? new List<PoliceReport>();

                Game.LogTrivial($"LSPD NextGen: Loaded {_reports.Count} reports, {_templates.Count} templates, {_draftReports.Count} drafts");
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error loading report data: {ex.Message}");
                _reports = new List<PoliceReport>();
                _templates = new List<ReportTemplate>();
                _draftReports = new List<PoliceReport>();
            }
        }

        /// <summary>
        /// Saves reports to file
        /// </summary>
        private void SaveReports()
        {
            JsonFileHelper.WriteToFile(_reportsDataPath, _reports);
        }

        /// <summary>
        /// Saves templates to file
        /// </summary>
        private void SaveTemplates()
        {
            JsonFileHelper.WriteToFile(_templatesPath, _templates);
        }

        /// <summary>
        /// Saves draft reports to file
        /// </summary>
        private void SaveDraftReports()
        {
            JsonFileHelper.WriteToFile(_draftReportsPath, _draftReports);
        }

        /// <summary>
        /// Cleanup method
        /// </summary>
        public void Cleanup()
        {
            try
            {
                // Save any pending data
                SaveReports();
                SaveTemplates();
                SaveDraftReports();

                Game.LogTrivial("LSPD NextGen: Report manager cleanup completed");
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error during report manager cleanup: {ex.Message}");
            }
        }
    }

    /// <summary>
    /// Represents a police report
    /// </summary>
    public class PoliceReport
    {
        public string ReportId { get; set; } = "";
        public string Type { get; set; } = "Incident Report";
        public string Title { get; set; } = "";
        public string OfficerInCharge { get; set; } = "";
        public List<string> AssistingOfficers { get; set; } = new List<string>();
        public string DateTime { get; set; } = "";
        public LocationInfo Location { get; set; } = new LocationInfo();
        public string Summary { get; set; } = "";
        public string Details { get; set; } = "";
        public List<InvolvedPerson> InvolvedPersons { get; set; } = new List<InvolvedPerson>();
        public List<EvidenceItem> Evidence { get; set; } = new List<EvidenceItem>();
        public List<Witness> Witnesses { get; set; } = new List<Witness>();
        public List<Charge> Charges { get; set; } = new List<Charge>();
        public string Disposition { get; set; } = "";
        public bool FollowUpRequired { get; set; } = false;
        public bool Approved { get; set; } = false;
        public string ApprovedBy { get; set; } = "";
        public string Status { get; set; } = "Draft";
        public string Created { get; set; } = "";
        public string LastModified { get; set; } = "";
    }

    /// <summary>
    /// Report template
    /// </summary>
    public class ReportTemplate
    {
        public string Name { get; set; } = "";
        public string Type { get; set; } = "";
        public string DefaultContent { get; set; } = "";
    }

    /// <summary>
    /// Person involved in an incident
    /// </summary>
    public class InvolvedPerson
    {
        public string Name { get; set; } = "";
        public string Role { get; set; } = ""; // Suspect, Victim, etc.
        public string Description { get; set; } = "";
        public string ContactInfo { get; set; } = "";
        public List<string> Charges { get; set; } = new List<string>();
    }

    /// <summary>
    /// Evidence item
    /// </summary>
    public class EvidenceItem
    {
        public string Type { get; set; } = "";
        public string Description { get; set; } = "";
        public string Location { get; set; } = "";
        public string CollectedBy { get; set; } = "";
        public string CollectedDate { get; set; } = "";
        public string ChainOfCustody { get; set; } = "";
    }

    /// <summary>
    /// Witness information
    /// </summary>
    public class Witness
    {
        public string Name { get; set; } = "";
        public string ContactInfo { get; set; } = "";
        public string Statement { get; set; } = "";
        public string InterviewedBy { get; set; } = "";
        public string InterviewDate { get; set; } = "";
    }

    /// <summary>
    /// Criminal charge
    /// </summary>
    public class Charge
    {
        public string Code { get; set; } = "";
        public string Description { get; set; } = "";
        public string Severity { get; set; } = ""; // Misdemeanor, Felony, etc.
        public string Status { get; set; } = ""; // Filed, Pending, etc.
    }
}
