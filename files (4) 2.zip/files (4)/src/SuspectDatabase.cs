using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Rage;

namespace LSPDNextGen
{
    /// <summary>
    /// Manages suspect database operations including person lookups, warrant checks, and criminal history
    /// </summary>
    public class SuspectDatabase
    {
        private readonly string _suspectsDataPath;
        private readonly string _warrantsDataPath;
        private readonly string _arrestsDataPath;
        private List<Suspect> _suspects;
        private List<Warrant> _warrants;
        private List<ArrestRecord> _arrests;

        public SuspectDatabase()
        {
            _suspectsDataPath = Path.Combine(DataBootstrapper.GetDataPath("Suspects"), "suspects.json");
            _warrantsDataPath = Path.Combine(DataBootstrapper.GetDataPath("Suspects"), "warrants.json");
            _arrestsDataPath = Path.Combine(DataBootstrapper.GetDataPath("Suspects"), "arrests.json");
            
            LoadData();
        }

        /// <summary>
        /// Searches for suspects by name (partial match)
        /// </summary>
        public List<Suspect> SearchByName(string firstName, string lastName = "")
        {
            try
            {
                var results = _suspects.Where(s => 
                    s.FirstName.Contains(firstName, StringComparison.OrdinalIgnoreCase)).ToList();

                if (!string.IsNullOrEmpty(lastName))
                {
                    results = results.Where(s => 
                        s.LastName.Contains(lastName, StringComparison.OrdinalIgnoreCase)).ToList();
                }

                Game.LogTrivial($"LSPD NextGen: Found {results.Count} suspects matching name search");
                return results;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error searching suspects by name: {ex.Message}");
                return new List<Suspect>();
            }
        }

        /// <summary>
        /// Searches for a suspect by exact ID
        /// </summary>
        public Suspect FindById(string suspectId)
        {
            try
            {
                return _suspects.FirstOrDefault(s => s.Id.Equals(suspectId, StringComparison.OrdinalIgnoreCase));
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error finding suspect by ID: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// Searches for suspects by physical description
        /// </summary>
        public List<Suspect> SearchByDescription(string race = "", string gender = "", string hairColor = "", string eyeColor = "")
        {
            try
            {
                var results = _suspects.AsQueryable();

                if (!string.IsNullOrEmpty(race))
                    results = results.Where(s => s.Race.Contains(race, StringComparison.OrdinalIgnoreCase));

                if (!string.IsNullOrEmpty(gender))
                    results = results.Where(s => s.Gender.Contains(gender, StringComparison.OrdinalIgnoreCase));

                if (!string.IsNullOrEmpty(hairColor))
                    results = results.Where(s => s.HairColor.Contains(hairColor, StringComparison.OrdinalIgnoreCase));

                if (!string.IsNullOrEmpty(eyeColor))
                    results = results.Where(s => s.EyeColor.Contains(eyeColor, StringComparison.OrdinalIgnoreCase));

                var resultList = results.ToList();
                Game.LogTrivial($"LSPD NextGen: Found {resultList.Count} suspects matching description");
                return resultList;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error searching suspects by description: {ex.Message}");
                return new List<Suspect>();
            }
        }

        /// <summary>
        /// Checks for active warrants for a suspect
        /// </summary>
        public List<Warrant> CheckWarrants(string suspectId)
        {
            try
            {
                var activeWarrants = _warrants.Where(w => 
                    w.SuspectId.Equals(suspectId, StringComparison.OrdinalIgnoreCase) && 
                    w.Status.Equals("Active", StringComparison.OrdinalIgnoreCase)).ToList();

                Game.LogTrivial($"LSPD NextGen: Found {activeWarrants.Count} active warrants for suspect {suspectId}");
                return activeWarrants;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error checking warrants: {ex.Message}");
                return new List<Warrant>();
            }
        }

        /// <summary>
        /// Gets criminal history for a suspect
        /// </summary>
        public List<ArrestRecord> GetCriminalHistory(string suspectId)
        {
            try
            {
                var history = _arrests.Where(a => 
                    a.SuspectId.Equals(suspectId, StringComparison.OrdinalIgnoreCase))
                    .OrderByDescending(a => DateTime.Parse(a.ArrestDate))
                    .ToList();

                Game.LogTrivial($"LSPD NextGen: Found {history.Count} arrest records for suspect {suspectId}");
                return history;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error getting criminal history: {ex.Message}");
                return new List<ArrestRecord>();
            }
        }

        /// <summary>
        /// Adds a new suspect to the database
        /// </summary>
        public bool AddSuspect(Suspect suspect)
        {
            try
            {
                if (string.IsNullOrEmpty(suspect.Id))
                {
                    suspect.Id = GenerateSuspectId();
                }

                if (FindById(suspect.Id) != null)
                {
                    Game.LogTrivial($"LSPD NextGen: Suspect with ID {suspect.Id} already exists");
                    return false;
                }

                suspect.Created = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                suspect.LastUpdated = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                _suspects.Add(suspect);
                SaveSuspects();

                Game.LogTrivial($"LSPD NextGen: Added suspect {suspect.FirstName} {suspect.LastName} (ID: {suspect.Id})");
                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error adding suspect: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Updates an existing suspect's information
        /// </summary>
        public bool UpdateSuspect(Suspect updatedSuspect)
        {
            try
            {
                var existingSuspect = FindById(updatedSuspect.Id);
                if (existingSuspect == null)
                {
                    Game.LogTrivial($"LSPD NextGen: Suspect with ID {updatedSuspect.Id} not found");
                    return false;
                }

                // Preserve creation date
                updatedSuspect.Created = existingSuspect.Created;
                updatedSuspect.LastUpdated = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                var index = _suspects.IndexOf(existingSuspect);
                _suspects[index] = updatedSuspect;

                SaveSuspects();
                Game.LogTrivial($"LSPD NextGen: Updated suspect {updatedSuspect.FirstName} {updatedSuspect.LastName}");
                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error updating suspect: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Adds a warrant for a suspect
        /// </summary>
        public bool AddWarrant(Warrant warrant)
        {
            try
            {
                if (string.IsNullOrEmpty(warrant.WarrantId))
                {
                    warrant.WarrantId = GenerateWarrantId();
                }

                warrant.IssueDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                warrant.Status = "Active";

                _warrants.Add(warrant);
                SaveWarrants();

                Game.LogTrivial($"LSPD NextGen: Added warrant {warrant.WarrantId} for suspect {warrant.SuspectId}");
                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error adding warrant: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Serves (executes) a warrant
        /// </summary>
        public bool ServeWarrant(string warrantId, string servingOfficer)
        {
            try
            {
                var warrant = _warrants.FirstOrDefault(w => w.WarrantId.Equals(warrantId, StringComparison.OrdinalIgnoreCase));
                if (warrant == null)
                {
                    Game.LogTrivial($"LSPD NextGen: Warrant {warrantId} not found");
                    return false;
                }

                warrant.Status = "Served";
                warrant.ServedDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                warrant.ServingOfficer = servingOfficer;

                SaveWarrants();
                Game.LogTrivial($"LSPD NextGen: Warrant {warrantId} served by {servingOfficer}");
                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error serving warrant: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Adds an arrest record
        /// </summary>
        public bool AddArrestRecord(ArrestRecord arrest)
        {
            try
            {
                if (string.IsNullOrEmpty(arrest.ArrestId))
                {
                    arrest.ArrestId = GenerateArrestId();
                }

                arrest.ArrestDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                _arrests.Add(arrest);
                SaveArrests();

                // Update suspect's danger level based on arrest history
                UpdateSuspectDangerLevel(arrest.SuspectId);

                Game.LogTrivial($"LSPD NextGen: Added arrest record {arrest.ArrestId} for suspect {arrest.SuspectId}");
                return true;
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error adding arrest record: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Gets suspects by gang affiliation
        /// </summary>
        public List<Suspect> GetSuspectsByGang(string gang)
        {
            try
            {
                return _suspects.Where(s => 
                    !string.IsNullOrEmpty(s.Gang) && 
                    s.Gang.Contains(gang, StringComparison.OrdinalIgnoreCase)).ToList();
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error getting suspects by gang: {ex.Message}");
                return new List<Suspect>();
            }
        }

        /// <summary>
        /// Gets suspects by danger level
        /// </summary>
        public List<Suspect> GetSuspectsByDangerLevel(string dangerLevel)
        {
            try
            {
                return _suspects.Where(s => 
                    s.DangerLevel.Equals(dangerLevel, StringComparison.OrdinalIgnoreCase)).ToList();
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error getting suspects by danger level: {ex.Message}");
                return new List<Suspect>();
            }
        }

        /// <summary>
        /// Generates a unique suspect ID
        /// </summary>
        private string GenerateSuspectId()
        {
            var random = new Random();
            string id;
            
            do
            {
                id = "SUSP" + random.Next(10000, 99999).ToString();
            } while (FindById(id) != null);

            return id;
        }

        /// <summary>
        /// Generates a unique warrant ID
        /// </summary>
        private string GenerateWarrantId()
        {
            var random = new Random();
            return "WRT" + DateTime.Now.ToString("yyyyMMdd") + random.Next(1000, 9999).ToString();
        }

        /// <summary>
        /// Generates a unique arrest ID
        /// </summary>
        private string GenerateArrestId()
        {
            var random = new Random();
            return "ARR" + DateTime.Now.ToString("yyyyMMdd") + random.Next(1000, 9999).ToString();
        }

        /// <summary>
        /// Updates a suspect's danger level based on their criminal history
        /// </summary>
        private void UpdateSuspectDangerLevel(string suspectId)
        {
            try
            {
                var suspect = FindById(suspectId);
                if (suspect == null) return;

                var arrestCount = _arrests.Count(a => a.SuspectId.Equals(suspectId, StringComparison.OrdinalIgnoreCase));
                var violentCrimes = _arrests.Count(a => 
                    a.SuspectId.Equals(suspectId, StringComparison.OrdinalIgnoreCase) && 
                    (a.Charges.Any(c => c.Contains("assault", StringComparison.OrdinalIgnoreCase) ||
                                      c.Contains("battery", StringComparison.OrdinalIgnoreCase) ||
                                      c.Contains("robbery", StringComparison.OrdinalIgnoreCase) ||
                                      c.Contains("murder", StringComparison.OrdinalIgnoreCase))));

                if (violentCrimes > 0 || arrestCount > 5)
                    suspect.DangerLevel = "High";
                else if (arrestCount > 2)
                    suspect.DangerLevel = "Medium";
                else
                    suspect.DangerLevel = "Low";

                UpdateSuspect(suspect);
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error updating danger level: {ex.Message}");
            }
        }

        /// <summary>
        /// Loads all data from files
        /// </summary>
        private void LoadData()
        {
            try
            {
                _suspects = JsonFileHelper.ReadFromFile<List<Suspect>>(_suspectsDataPath, true) ?? new List<Suspect>();
                _warrants = JsonFileHelper.ReadFromFile<List<Warrant>>(_warrantsDataPath, true) ?? new List<Warrant>();
                _arrests = JsonFileHelper.ReadFromFile<List<ArrestRecord>>(_arrestsDataPath, true) ?? new List<ArrestRecord>();

                Game.LogTrivial($"LSPD NextGen: Loaded {_suspects.Count} suspects, {_warrants.Count} warrants, {_arrests.Count} arrests");
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error loading suspect database: {ex.Message}");
            }
        }

        /// <summary>
        /// Saves suspects to file
        /// </summary>
        private void SaveSuspects()
        {
            JsonFileHelper.WriteToFile(_suspectsDataPath, _suspects);
        }

        /// <summary>
        /// Saves warrants to file
        /// </summary>
        private void SaveWarrants()
        {
            JsonFileHelper.WriteToFile(_warrantsDataPath, _warrants);
        }

        /// <summary>
        /// Saves arrests to file
        /// </summary>
        private void SaveArrests()
        {
            JsonFileHelper.WriteToFile(_arrestsDataPath, _arrests);
        }

        /// <summary>
        /// Cleanup method
        /// </summary>
        public void Cleanup()
        {
            try
            {
                // Save any pending changes
                SaveSuspects();
                SaveWarrants();
                SaveArrests();

                Game.LogTrivial("LSPD NextGen: Suspect database cleanup completed");
            }
            catch (Exception ex)
            {
                Game.LogTrivial($"LSPD NextGen: Error during suspect database cleanup: {ex.Message}");
            }
        }
    }

    /// <summary>
    /// Represents a suspect in the database
    /// </summary>
    public class Suspect
    {
        public string Id { get; set; } = "";
        public string FirstName { get; set; } = "";
        public string LastName { get; set; } = "";
        public string DateOfBirth { get; set; } = "";
        public string Gender { get; set; } = "";
        public string Race { get; set; } = "";
        public string Height { get; set; } = "";
        public string Weight { get; set; } = "";
        public string EyeColor { get; set; } = "";
        public string HairColor { get; set; } = "";
        public string Address { get; set; } = "";
        public string Phone { get; set; } = "";
        public List<string> Warrants { get; set; } = new List<string>();
        public List<string> PriorArrests { get; set; } = new List<string>();
        public List<string> KnownAssociates { get; set; } = new List<string>();
        public string Gang { get; set; } = "";
        public string Notes { get; set; } = "";
        public string DangerLevel { get; set; } = "Low";
        public string LastSeen { get; set; } = "";
        public string Created { get; set; } = "";
        public string LastUpdated { get; set; } = "";
    }

    /// <summary>
    /// Represents a warrant
    /// </summary>
    public class Warrant
    {
        public string WarrantId { get; set; } = "";
        public string SuspectId { get; set; } = "";
        public string Type { get; set; } = "";
        public string Description { get; set; } = "";
        public string IssuingCourt { get; set; } = "";
        public string IssuingJudge { get; set; } = "";
        public string IssueDate { get; set; } = "";
        public string Status { get; set; } = "Active";
        public string ServedDate { get; set; } = "";
        public string ServingOfficer { get; set; } = "";
        public string BondAmount { get; set; } = "";
        public List<string> Charges { get; set; } = new List<string>();
    }

    /// <summary>
    /// Represents an arrest record
    /// </summary>
    public class ArrestRecord
    {
        public string ArrestId { get; set; } = "";
        public string SuspectId { get; set; } = "";
        public string ArrestingOfficer { get; set; } = "";
        public string ArrestDate { get; set; } = "";
        public string Location { get; set; } = "";
        public List<string> Charges { get; set; } = new List<string>();
        public string Disposition { get; set; } = "";
        public string Notes { get; set; } = "";
        public string CaseNumber { get; set; } = "";
    }
}
