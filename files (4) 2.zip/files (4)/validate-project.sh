#!/bin/bash

echo
echo "🔍 LSPD NextGen - Final Project Validation"
echo "=========================================="
echo

# Counter for issues
issues=0

echo "📋 Project Structure Validation:"
echo

# Check source files
if [ -d "src" ] && [ "$(find src -name "*.cs" | wc -l)" -eq 7 ]; then
    echo "✅ Source files: 7 C# files found"
else
    echo "❌ Source files: Missing or incomplete"
    ((issues++))
fi

# Check project files
if [ -f "LSPDNextGen.csproj" ] && [ -f "LSPDNextGen.sln" ]; then
    echo "✅ Project files: .csproj and .sln present"
else
    echo "❌ Project files: Missing project or solution file"
    ((issues++))
fi

# Check Release structure
if [ -d "Release/plugins" ] && [ -d "Release/lspdfr/data/LSPDNextGen" ]; then
    echo "✅ LSPDFR structure: Proper folder layout"
else
    echo "❌ LSPDFR structure: Missing Release folders"
    ((issues++))
fi

# Check data files
data_files=("settings.json" "officers.json" "callouts.json" "reports.json" "suspects.json" "vehicles.json")
missing_data=0
for file in "${data_files[@]}"; do
    if [ ! -f "Release/lspdfr/data/LSPDNextGen/$file" ]; then
        ((missing_data++))
    fi
done

if [ $missing_data -eq 0 ]; then
    echo "✅ Data files: All 6 JSON files present"
else
    echo "❌ Data files: $missing_data missing JSON files"
    ((issues++))
fi

# Check configuration
if [ -f "LSPDNextGen.ini" ] && [ -f "Release/plugins/LSPDNextGen.ini" ]; then
    echo "✅ Configuration: INI files present"
else
    echo "❌ Configuration: Missing INI files"
    ((issues++))
fi

# Check build scripts
build_scripts=("build.bat" "build-msbuild.bat" "setup-dev.bat")
build_count=0
for script in "${build_scripts[@]}"; do
    if [ -f "$script" ]; then
        ((build_count++))
    fi
done

if [ $build_count -ge 2 ]; then
    echo "✅ Build scripts: $build_count Windows build scripts"
else
    echo "❌ Build scripts: Missing Windows build scripts"
    ((issues++))
fi

# Check documentation
docs=("README.md" "INSTALL.md" "BUILD-TROUBLESHOOTING.md" "README-MACOS-DEV.md")
doc_count=0
for doc in "${docs[@]}"; do
    if [ -f "$doc" ]; then
        ((doc_count++))
    fi
done

if [ $doc_count -ge 3 ]; then
    echo "✅ Documentation: $doc_count documentation files"
else
    echo "❌ Documentation: Insufficient documentation"
    ((issues++))
fi

# Check GitHub Actions
if [ -f ".github/workflows/build.yml" ]; then
    echo "✅ CI/CD: GitHub Actions workflow present"
else
    echo "❌ CI/CD: Missing GitHub Actions workflow"
    ((issues++))
fi

echo
echo "🔧 Build Environment Validation:"
echo

# Check for macOS-specific tools
if [ -f "build-info-macos.sh" ] && [ -f "create-release.sh" ]; then
    echo "✅ macOS tools: Distribution scripts present"
else
    echo "❌ macOS tools: Missing distribution scripts"
    ((issues++))
fi

# Check C# syntax (basic - warning only)
for cs_file in src/*.cs; do
    if [ -f "$cs_file" ]; then
        # Basic syntax check for common issues
        if grep -q "using LSPD_First_Response\|using Rage" "$cs_file"; then
            continue
        else
            echo "⚠️  Warning: $cs_file may be missing LSPDFR imports"
        fi
    fi
done

echo
echo "📊 Final Assessment:"
echo "===================="

total_checks=9
passed=$((total_checks - issues))

echo "Passed: $passed/$total_checks checks"
echo "Issues: $issues"

if [ $issues -eq 0 ]; then
    echo
    echo "🎉 PERFECT! Your LSPDFR plugin project is 100% ready!"
    echo
    echo "✅ All systems go:"
    echo "   • Complete source code"
    echo "   • Proper LSPDFR structure"
    echo "   • Build scripts for Windows"
    echo "   • Comprehensive documentation"
    echo "   • Distribution tools"
    echo
    echo "🚀 Ready for:"
    echo "   • Windows users to build and install"
    echo "   • GitHub repository publishing"
    echo "   • LSPDFR community distribution"
    echo "   • Professional release"
    echo
    echo "💡 Next steps:"
    echo "   1. Run ./create-release.sh to package for distribution"
    echo "   2. Share with Windows LSPDFR community"
    echo "   3. Publish on GitHub for open source collaboration"
    
elif [ $issues -le 2 ]; then
    echo
    echo "✅ EXCELLENT! Minor issues found but project is ready for distribution."
    echo "The identified issues are non-critical and won't prevent functionality."
    
elif [ $issues -le 4 ]; then
    echo
    echo "⚠️  GOOD! Some issues found but project is largely complete."
    echo "Address the issues above for a perfect release."
    
else
    echo
    echo "❌ NEEDS WORK! Several critical issues found."
    echo "Please address the issues above before distribution."
fi

echo
echo "📁 Project Statistics:"
echo "   Source files: $(find src -name "*.cs" 2>/dev/null | wc -l)"
echo "   Total files: $(find . -type f | wc -l)"
echo "   Documentation: $(find . -name "*.md" | wc -l) files"

echo
echo "=========================================="
